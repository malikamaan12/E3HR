import express from 'express';
import { authenticate } from '../middleware/auth';
import { db } from '../db';
import { employees, leaves, attendance, documents, performanceReviews, users } from '@shared/schema';
import { eq, and, gte, lte, desc, sql } from 'drizzle-orm';

const router = express.Router();

/**
 * Get employee dashboard data
 * GET /api/employee/dashboard
 */
router.get('/dashboard', authenticate, async (req: any, res) => {
  try {
    const userId = req.user?.userId;
    
    if (!userId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    
    // Get user record first to find matching employee by email or qidNumber
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Get employee record by matching qidNumber or email
    const employeeResults = await db.select().from(employees).where(
      user.qidNumber 
        ? eq(employees.qidNumber, user.qidNumber)
        : eq(employees.personalEmail, user.email)
    );
    const employee = employeeResults[0];
    
    if (!employee) {
      return res.status(404).json({ message: 'Employee record not found' });
    }
    
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    
    // Get attendance data
    const [todayAttendance] = await db.select()
      .from(attendance)
      .where(
        and(
          eq(attendance.employeeId, employee.id),
          eq(attendance.date, today.toISOString().split('T')[0])
        )
      );
    
    const monthlyAttendance = await db.select({
      count: sql<number>`count(*)`
    })
      .from(attendance)
      .where(
        and(
          eq(attendance.employeeId, employee.id),
          gte(attendance.date, startOfMonth.toISOString().split('T')[0]),
          lte(attendance.date, endOfMonth.toISOString().split('T')[0]),
          eq(attendance.status, 'present')
        )
      );
    
    const workingDays = 22; // Approximate working days in a month
    const attendancePercentage = Math.round((monthlyAttendance[0]?.count || 0) / workingDays * 100);
    
    // Get leave data
    const leaveData = await db.select({
      status: leaves.status,
      totalDays: leaves.totalDays
    })
      .from(leaves)
      .where(eq(leaves.employeeId, employee.id));
    
    const usedLeaves = leaveData
      .filter(l => l.status === 'approved')
      .reduce((sum, l) => sum + (l.totalDays || 0), 0);
    
    const pendingLeaves = leaveData
      .filter(l => l.status === 'pending')
      .length;
    
    // Get documents count
    const documentsCount = await db.select({
      total: sql<number>`count(*)`,
      expiring: sql<number>`count(*) filter (where expiry_date < current_date + interval '30 days')`
    })
      .from(documents)
      .where(eq(documents.employeeId, employee.id));
    
    // Get performance data (only for permanent and contract employees)
    let performanceData = null;
    if (employee.type === 'permanent' || employee.type === 'contract') {
      const [latestReview] = await db.select()
        .from(performanceReviews)
        .where(eq(performanceReviews.employeeId, employee.id))
        .orderBy(desc(performanceReviews.completedDate))
        .limit(1);
      
      performanceData = {
        rating: latestReview?.overallRating || null,
        lastReview: latestReview?.completedDate || null,
        goals: 0 // Would need goals table
      };
    }
    
    // Get payroll data (only for permanent and contract employees)
    let payrollData = null;
    if (employee.type === 'permanent' || employee.type === 'contract') {
      // Payroll data would be fetched here when payroll table is available
      const nextPayDate = new Date();
      nextPayDate.setMonth(nextPayDate.getMonth() + 1);
      nextPayDate.setDate(25); // Assuming 25th is payday
      
      payrollData = {
        lastPayslip: null, // Would fetch from payroll table
        nextPayDate: nextPayDate.toISOString().split('T')[0]
      };
    }
    
    const dashboardData = {
      attendance: {
        status: todayAttendance?.status || 'not_checked_in',
        checkInTime: todayAttendance?.checkIn ? new Date(todayAttendance.checkIn).toLocaleTimeString() : null,
        totalHours: todayAttendance?.totalWorkHours || 0,
        monthlyAttendance: attendancePercentage
      },
      leaves: {
        available: 21 - usedLeaves, // Assuming 21 days annual leave
        used: usedLeaves,
        pending: pendingLeaves,
        upcoming: []
      },
      documents: {
        total: documentsCount[0]?.total || 0,
        expiring: documentsCount[0]?.expiring || 0
      },
      performance: performanceData,
      payroll: payrollData
    };
    
    res.json(dashboardData);
    
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard data' });
  }
});

export default router;