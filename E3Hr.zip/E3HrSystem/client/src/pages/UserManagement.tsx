import React, { useState, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  PlusCircle, 
  Pencil, 
  Trash2, 
  UserPlus, 
  Shield,
  CheckCircle,
  XCircle, 
  Search,
  ChevronDown 
} from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Status type to ensure correct values are used
type UserStatus = 'active' | 'inactive' | 'locked';

// User interface for type safety
interface MockUser {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  status: UserStatus;
  lastLogin: string;
  createdAt: string;
}

// Mock data for users
const mockUsers: MockUser[] = [
  {
    id: 1,
    username: 'admin',
    email: 'admin@example.com',
    firstName: 'Admin',
    lastName: 'User',
    role: 'Admin',
    status: 'active',
    lastLogin: '2025-04-16T08:30:00Z',
    createdAt: '2025-01-01T00:00:00Z',
  },
  {
    id: 2,
    username: 'hrmanager',
    email: 'hr.manager@example.com',
    firstName: 'Ahmad',
    lastName: 'Al-Mansoori',
    role: 'HR Manager',
    status: 'active',
    lastLogin: '2025-04-15T14:20:00Z',
    createdAt: '2025-01-02T00:00:00Z',
  },
  {
    id: 3,
    username: 'employee1',
    email: 'employee1@example.com',
    firstName: 'Mohammed',
    lastName: 'Al-Thani',
    role: 'Employee',
    status: 'active',
    lastLogin: '2025-04-14T09:15:00Z',
    createdAt: '2025-01-03T00:00:00Z',
  },
  {
    id: 4,
    username: 'finance',
    email: 'finance@example.com',
    firstName: 'Sara',
    lastName: 'Al-Sulaiti',
    role: 'Finance Admin',
    status: 'inactive',
    lastLogin: '2025-03-20T11:45:00Z',
    createdAt: '2025-01-05T00:00:00Z',
  },
  {
    id: 5, 
    username: 'eventmanager',
    email: 'events@example.com',
    firstName: 'Fatima',
    lastName: 'Al-Mansouri',
    role: 'Event Manager',
    status: 'locked',
    lastLogin: '2025-04-10T16:30:00Z',
    createdAt: '2025-02-15T00:00:00Z',
  }
];

// Mock data for roles
const mockRoles = [
  { id: 1, name: 'Admin', description: 'Full system access', permissions: ['all'] },
  { id: 2, name: 'HR Manager', description: 'Manage all HR functions', permissions: ['hr.view', 'hr.edit', 'employees.view', 'employees.edit', 'leave.approve'] },
  { id: 3, name: 'Employee', description: 'Basic employee access', permissions: ['profile.view', 'profile.edit', 'leave.request'] },
  { id: 4, name: 'Finance Admin', description: 'Manage financial aspects', permissions: ['finance.view', 'finance.edit', 'payroll.manage'] },
  { id: 5, name: 'Event Manager', description: 'Manage events and staff', permissions: ['events.view', 'events.edit', 'staff.assign'] },
  { id: 6, name: 'Manager', description: 'Department manager access', permissions: ['team.view', 'team.edit', 'leave.approve'] },
  { id: 7, name: 'Recruiter', description: 'Recruitment functions', permissions: ['candidates.view', 'candidates.edit', 'interviews.schedule'] },
];

// Type definitions for form schemas
const userFormSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.string().min(1, "Please select a role"),
  status: z.enum(["active", "inactive", "locked"]),
  password: z.string().min(6, "Password must be at least 6 characters").optional(),
});

const roleFormSchema = z.object({
  name: z.string().min(2, "Role name must be at least 2 characters"),
  description: z.string().min(1, "Description is required"),
  permissions: z.array(z.string()).min(1, "Select at least one permission"),
});

type UserFormValues = z.infer<typeof userFormSchema>;
type RoleFormValues = z.infer<typeof roleFormSchema>;

// Component for status badge with appropriate color
const StatusBadge = ({ status }: { status: string }) => {
  let variant: "default" | "destructive" | "outline" | "secondary" = "default";
  
  switch (status) {
    case 'active':
      variant = "default";
      break;
    case 'inactive':
      variant = "secondary";
      break;
    case 'locked':
      variant = "destructive";
      break;
    default:
      variant = "outline";
  }
  
  return <Badge variant={variant}>{status}</Badge>;
};

// Format date for display
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
};

// Mock all available permissions for the system
const allPermissions = [
  { id: 'hr.view', group: 'HR', name: 'View HR Data' },
  { id: 'hr.edit', group: 'HR', name: 'Edit HR Data' },
  { id: 'employees.view', group: 'Employees', name: 'View Employees' },
  { id: 'employees.edit', group: 'Employees', name: 'Edit Employees' },
  { id: 'payroll.view', group: 'Payroll', name: 'View Payroll' },
  { id: 'payroll.edit', group: 'Payroll', name: 'Edit Payroll' },
  { id: 'payroll.approve', group: 'Payroll', name: 'Approve Payroll' },
  { id: 'leave.request', group: 'Leave', name: 'Request Leave' },
  { id: 'leave.approve', group: 'Leave', name: 'Approve Leave' },
  { id: 'documents.view', group: 'Documents', name: 'View Documents' },
  { id: 'documents.upload', group: 'Documents', name: 'Upload Documents' },
  { id: 'events.view', group: 'Events', name: 'View Events' },
  { id: 'events.edit', group: 'Events', name: 'Edit Events' },
  { id: 'staff.assign', group: 'Staff', name: 'Assign Staff' },
  { id: 'reports.view', group: 'Reports', name: 'View Reports' },
  { id: 'reports.generate', group: 'Reports', name: 'Generate Reports' },
  { id: 'settings.view', group: 'Settings', name: 'View Settings' },
  { id: 'settings.edit', group: 'Settings', name: 'Edit Settings' },
  { id: 'profile.view', group: 'Profile', name: 'View Profile' },
  { id: 'profile.edit', group: 'Profile', name: 'Edit Profile' },
  { id: 'team.view', group: 'Team', name: 'View Team' },
  { id: 'team.edit', group: 'Team', name: 'Edit Team' },
  { id: 'candidates.view', group: 'Recruitment', name: 'View Candidates' },
  { id: 'candidates.edit', group: 'Recruitment', name: 'Edit Candidates' },
  { id: 'interviews.schedule', group: 'Recruitment', name: 'Schedule Interviews' },
  { id: 'all', group: 'System', name: 'All Permissions' },
];

// User Form Component
const UserForm = ({ 
  defaultValues, 
  onSubmit, 
  onCancel 
}: { 
  defaultValues?: Partial<UserFormValues>,
  onSubmit: (data: UserFormValues) => void,
  onCancel: () => void
}) => {
  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: defaultValues || {
      username: '',
      email: '',
      firstName: '',
      lastName: '',
      role: '',
      status: 'active',
    }
  });
  
  // Determine if we're editing (has defaultValues with id) or creating new user
  const isEditing = !!defaultValues?.username;
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>First Name</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="First name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="lastName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Last Name</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="Last name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Username</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Username" />
              </FormControl>
              <FormDescription>
                Used for login. Cannot be changed after creation.
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input {...field} type="email" placeholder="email@example.com" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {!isEditing && (
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Password</FormLabel>
                <FormControl>
                  <Input {...field} type="password" placeholder="•••••••••" />
                </FormControl>
                <FormDescription>
                  Must be at least 6 characters long.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        <FormField
          control={form.control}
          name="role"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Role</FormLabel>
              <Select 
                onValueChange={field.onChange} 
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {mockRoles.map(role => (
                    <SelectItem key={role.id} value={role.name}>
                      {role.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Status</FormLabel>
              <Select 
                onValueChange={field.onChange} 
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="locked">Locked</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <DialogFooter className="mt-6">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit">
            {isEditing ? 'Update User' : 'Create User'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
};

// Role Form Component
const RoleForm = ({
  defaultValues, 
  onSubmit, 
  onCancel 
}: { 
  defaultValues?: Partial<RoleFormValues>,
  onSubmit: (data: RoleFormValues) => void,
  onCancel: () => void
}) => {
  const form = useForm<RoleFormValues>({
    resolver: zodResolver(roleFormSchema),
    defaultValues: defaultValues || {
      name: '',
      description: '',
      permissions: [],
    }
  });
  
  // Group permissions by category
  const permissionsByGroup = allPermissions.reduce((acc, permission) => {
    if (!acc[permission.group]) {
      acc[permission.group] = [];
    }
    acc[permission.group].push(permission);
    return acc;
  }, {} as Record<string, typeof allPermissions>);
  
  // Determine if we're editing or creating new role
  const isEditing = !!defaultValues?.name;
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Role Name</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Role name" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Input {...field} placeholder="Role description" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="permissions"
          render={() => (
            <FormItem>
              <FormLabel>Permissions</FormLabel>
              <FormDescription>
                Select the permissions for this role
              </FormDescription>
              
              <div className="border rounded-md p-4 mt-2 space-y-4">
                {Object.entries(permissionsByGroup).map(([group, permissions]) => (
                  <div key={group} className="space-y-2">
                    <h4 className="font-medium text-sm">{group}</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {permissions.map(permission => (
                        <FormField
                          key={permission.id}
                          control={form.control}
                          name="permissions"
                          render={({ field }) => {
                            return (
                              <FormItem
                                key={permission.id}
                                className="flex flex-row items-center space-x-2 space-y-0"
                              >
                                <FormControl>
                                  <div className="flex items-center space-x-2">
                                    <Switch
                                      checked={field.value?.includes(permission.id)}
                                      onCheckedChange={(checked) => {
                                        const currentPermissions = field.value || [];
                                        if (checked) {
                                          if (permission.id === 'all') {
                                            // If selecting 'all', replace with all permission IDs
                                            field.onChange(allPermissions.map(p => p.id));
                                          } else {
                                            field.onChange([...currentPermissions, permission.id]);
                                          }
                                        } else {
                                          if (permission.id === 'all') {
                                            // If deselecting 'all', remove all permissions
                                            field.onChange([]);
                                          } else {
                                            // Remove this permission and 'all' if it's included
                                            field.onChange(
                                              currentPermissions.filter(
                                                p => p !== permission.id && p !== 'all'
                                              )
                                            );
                                          }
                                        }
                                      }}
                                    />
                                    <span className="text-sm">{permission.name}</span>
                                  </div>
                                </FormControl>
                              </FormItem>
                            );
                          }}
                        />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <DialogFooter className="mt-6">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button type="submit">
            {isEditing ? 'Update Role' : 'Create Role'}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
};

// Main User Management Component
const UserManagement: React.FC = () => {
  const { toast } = useToast();
  const [users, setUsers] = useState(mockUsers);
  const [roles, setRoles] = useState(mockRoles);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUserDialogOpen, setIsUserDialogOpen] = useState(false);
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<typeof mockUsers[0] | null>(null);
  const [selectedRole, setSelectedRole] = useState<typeof mockRoles[0] | null>(null);
  const [currentTab, setCurrentTab] = useState('users');
  
  // Filter users based on search query
  const filteredUsers = users.filter(user => {
    const searchLower = searchQuery.toLowerCase();
    return (
      user.username.toLowerCase().includes(searchLower) ||
      user.email.toLowerCase().includes(searchLower) ||
      user.firstName.toLowerCase().includes(searchLower) ||
      user.lastName.toLowerCase().includes(searchLower) ||
      user.role.toLowerCase().includes(searchLower)
    );
  });
  
  // Filter roles based on search query
  const filteredRoles = roles.filter(role => {
    const searchLower = searchQuery.toLowerCase();
    return (
      role.name.toLowerCase().includes(searchLower) ||
      role.description.toLowerCase().includes(searchLower)
    );
  });
  
  // Handle creating or updating a user
  const handleUserSubmit = (data: UserFormValues) => {
    if (selectedUser) {
      // Update existing user
      const updatedUsers = users.map(user => 
        user.id === selectedUser.id ? { ...user, ...data } : user
      );
      setUsers(updatedUsers);
      toast({
        title: "User updated",
        description: `${data.firstName} ${data.lastName} was updated successfully.`,
      });
    } else {
      // Create new user
      const newUser = {
        id: users.length + 1,
        ...data,
        lastLogin: '',
        createdAt: new Date().toISOString(),
      };
      setUsers([...users, newUser]);
      toast({
        title: "User created",
        description: `${data.firstName} ${data.lastName} was created successfully.`,
      });
    }
    setIsUserDialogOpen(false);
    setSelectedUser(null);
  };
  
  // Handle creating or updating a role
  const handleRoleSubmit = (data: RoleFormValues) => {
    if (selectedRole) {
      // Update existing role
      const updatedRoles = roles.map(role => 
        role.id === selectedRole.id ? { ...role, ...data } : role
      );
      setRoles(updatedRoles);
      toast({
        title: "Role updated",
        description: `Role "${data.name}" was updated successfully.`,
      });
    } else {
      // Create new role
      const newRole = {
        id: roles.length + 1,
        ...data,
      };
      setRoles([...roles, newRole]);
      toast({
        title: "Role created",
        description: `Role "${data.name}" was created successfully.`,
      });
    }
    setIsRoleDialogOpen(false);
    setSelectedRole(null);
  };
  
  // Handle deleting a user
  const handleDeleteUser = (userId: number) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      const updatedUsers = users.filter(user => user.id !== userId);
      setUsers(updatedUsers);
      toast({
        title: "User deleted",
        description: "The user has been deleted successfully.",
      });
    }
  };
  
  // Handle deleting a role
  const handleDeleteRole = (roleId: number) => {
    // Check if any users are using this role
    const usersWithRole = users.filter(
      user => roles.find(r => r.id === roleId)?.name === user.role
    );
    
    if (usersWithRole.length > 0) {
      toast({
        title: "Cannot delete role",
        description: `This role is assigned to ${usersWithRole.length} user(s). Reassign users before deleting.`,
        variant: "destructive",
      });
      return;
    }
    
    if (window.confirm('Are you sure you want to delete this role?')) {
      const updatedRoles = roles.filter(role => role.id !== roleId);
      setRoles(updatedRoles);
      toast({
        title: "Role deleted",
        description: "The role has been deleted successfully.",
      });
    }
  };
  
  // Edit user handler
  const handleEditUser = (user: MockUser) => {
    // Create a user form values object from the MockUser
    const userFormValues: Partial<UserFormValues> = {
      username: user.username,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      status: user.status // This is now typed as UserStatus
    };
    
    setSelectedUser(user);
    setIsUserDialogOpen(true);
  };
  
  // Edit role handler
  const handleEditRole = (role: typeof mockRoles[0]) => {
    setSelectedRole(role);
    setIsRoleDialogOpen(true);
  };
  
  // Reset selection when dialogs close
  const handleUserDialogClose = () => {
    setIsUserDialogOpen(false);
    setSelectedUser(null);
  };
  
  const handleRoleDialogClose = () => {
    setIsRoleDialogOpen(false);
    setSelectedRole(null);
  };
  
  return (
    <div className="container mx-auto py-6 space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-muted-foreground">Manage users, roles, and permissions</p>
        </div>
      </div>
      
      <div>
        <Tabs value={currentTab} onValueChange={setCurrentTab}>
          <div className="flex justify-between items-center">
            <TabsList>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="roles">Roles & Permissions</TabsTrigger>
            </TabsList>
            
            <div className="flex space-x-2">
              <div className="relative w-64">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              {currentTab === 'users' ? (
                <Dialog open={isUserDialogOpen} onOpenChange={setIsUserDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => setSelectedUser(null)}>
                      <UserPlus className="mr-2 h-4 w-4" />
                      Add User
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[600px]">
                    <DialogHeader>
                      <DialogTitle>
                        {selectedUser ? 'Edit User' : 'Create New User'}
                      </DialogTitle>
                      <DialogDescription>
                        {selectedUser 
                          ? 'Update user information and permissions' 
                          : 'Fill in the details to create a new user'
                        }
                      </DialogDescription>
                    </DialogHeader>
                    <UserForm 
                      defaultValues={selectedUser ? {
                        username: selectedUser.username,
                        email: selectedUser.email,
                        firstName: selectedUser.firstName,
                        lastName: selectedUser.lastName,
                        role: selectedUser.role,
                        status: selectedUser.status
                      } : undefined}
                      onSubmit={handleUserSubmit}
                      onCancel={handleUserDialogClose}
                    />
                  </DialogContent>
                </Dialog>
              ) : (
                <Dialog open={isRoleDialogOpen} onOpenChange={setIsRoleDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => setSelectedRole(null)}>
                      <Shield className="mr-2 h-4 w-4" />
                      Add Role
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[700px]">
                    <DialogHeader>
                      <DialogTitle>
                        {selectedRole ? 'Edit Role' : 'Create New Role'}
                      </DialogTitle>
                      <DialogDescription>
                        {selectedRole 
                          ? 'Update role and permission settings' 
                          : 'Define a new role with specific permissions'
                        }
                      </DialogDescription>
                    </DialogHeader>
                    <RoleForm 
                      defaultValues={selectedRole 
                        ? {
                            name: selectedRole.name,
                            description: selectedRole.description,
                            permissions: selectedRole.permissions,
                          } 
                        : undefined
                      }
                      onSubmit={handleRoleSubmit}
                      onCancel={handleRoleDialogClose}
                    />
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
          
          <TabsContent value="users" className="mt-6">
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Username</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Login</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No users found matching your search criteria.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredUsers.map(user => (
                        <TableRow key={user.id}>
                          <TableCell>
                            {user.firstName} {user.lastName}
                          </TableCell>
                          <TableCell>{user.username}</TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>{user.role}</TableCell>
                          <TableCell>
                            <StatusBadge status={user.status} />
                          </TableCell>
                          <TableCell>
                            {user.lastLogin ? formatDate(user.lastLogin) : 'Never'}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end space-x-2">
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => handleEditUser(user)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => handleDeleteUser(user.id)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="roles" className="mt-6">
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Permissions</TableHead>
                      <TableHead>Users Assigned</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredRoles.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No roles found matching your search criteria.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredRoles.map(role => {
                        const usersWithRole = users.filter(u => u.role === role.name);
                        return (
                          <TableRow key={role.id}>
                            <TableCell className="font-medium">{role.name}</TableCell>
                            <TableCell>{role.description}</TableCell>
                            <TableCell>
                              {role.permissions.includes('all') ? (
                                <Badge variant="secondary">All Permissions</Badge>
                              ) : (
                                <div className="flex flex-wrap gap-1">
                                  {role.permissions.length > 3 ? (
                                    <>
                                      {role.permissions.slice(0, 2).map(perm => (
                                        <Badge key={perm} variant="outline" className="text-xs">
                                          {perm}
                                        </Badge>
                                      ))}
                                      <Badge variant="outline" className="text-xs">
                                        +{role.permissions.length - 2} more
                                      </Badge>
                                    </>
                                  ) : (
                                    role.permissions.map(perm => (
                                      <Badge key={perm} variant="outline" className="text-xs">
                                        {perm}
                                      </Badge>
                                    ))
                                  )}
                                </div>
                              )}
                            </TableCell>
                            <TableCell>{usersWithRole.length}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-2">
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  onClick={() => handleEditRole(role)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="icon"
                                  onClick={() => handleDeleteRole(role.id)}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default UserManagement;