import { db } from "../db";
import { 
  announcements, 
  users,
  type InsertAnnouncement, 
  type Announcement,
  employees,
  notificationPreferences,
  notifications
} from "@shared/schema";
import { eq, and, or, desc, isNull, gt } from "drizzle-orm";
import slackService from "./slack";
import notificationService from "./notifications";

// Function to create an announcement
export async function createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
  try {
    const [createdAnnouncement] = await db.insert(announcements)
      .values(announcement)
      .returning();
    
    // Get author information for notification delivery
    const author = await db.select({
      firstName: users.firstName,
      lastName: users.lastName
    })
    .from(users)
    .where(eq(users.id, announcement.authorId))
    .limit(1);
    
    const authorName = author.length > 0 
      ? `${author[0].firstName} ${author[0].lastName}`
      : "System";
    
    // Send to Slack if the announcement should be broadcast to all platforms
    if (announcement.targetAudience === 'all') {
      await slackService.sendAnnouncement(
        announcement.title,
        announcement.content,
        authorName
      );
    }
    
    // Create notifications for relevant employees
    await notifyEmployeesAboutAnnouncement(createdAnnouncement, authorName);
    
    return createdAnnouncement;
  } catch (error) {
    console.error("Error creating announcement:", error);
    throw error;
  }
}

// Function to get all active announcements
export async function getActiveAnnouncements(limit: number = 10): Promise<Announcement[]> {
  try {
    const today = new Date().toISOString().slice(0, 10);
    
    const activeAnnouncements = await db.select()
      .from(announcements)
      .where(and(
        eq(announcements.isActive, true),
        or(
          isNull(announcements.expiryDate),
          gt(announcements.expiryDate, today)
        )
      ))
      .orderBy(desc(announcements.isPinned), desc(announcements.createdAt))
      .limit(limit);
    
    return activeAnnouncements;
  } catch (error) {
    console.error("Error fetching active announcements:", error);
    return [];
  }
}

// Function to get announcements for a specific department
export async function getDepartmentAnnouncements(department: string, limit: number = 10): Promise<Announcement[]> {
  try {
    const today = new Date().toISOString().slice(0, 10);
    
    const departmentAnnouncements = await db.select()
      .from(announcements)
      .where(and(
        eq(announcements.isActive, true),
        or(
          isNull(announcements.expiryDate),
          gt(announcements.expiryDate, today)
        ),
        or(
          eq(announcements.targetAudience, 'all'),
          and(
            eq(announcements.targetAudience, 'department'),
            eq(announcements.targetDepartment, department)
          )
        )
      ))
      .orderBy(desc(announcements.isPinned), desc(announcements.createdAt))
      .limit(limit);
    
    return departmentAnnouncements;
  } catch (error) {
    console.error("Error fetching department announcements:", error);
    return [];
  }
}

// Helper function to notify employees about a new announcement
async function notifyEmployeesAboutAnnouncement(announcement: Announcement, authorName: string): Promise<void> {
  try {
    // Build query to find target employees based on announcement target audience
    const employeeFilters = [
      eq(notificationPreferences.announcements, true),
    ];

    if (announcement.targetAudience === 'department' && announcement.targetDepartment) {
      employeeFilters.push(eq(employees.department, announcement.targetDepartment));
    }

    if (announcement.targetAudience === 'role' && announcement.targetRole) {
      employeeFilters.push(eq(employees.position, announcement.targetRole));
    }

    const targetEmployeesQuery = db.select({
      id: employees.id,
      userId: users.id,
      department: employees.department
    })
    .from(employees)
    .innerJoin(
      notificationPreferences,
      eq(notificationPreferences.employeeId, employees.id)
    )
    .innerJoin(
      users,
      or(
        eq(users.email, employees.workEmail),
        eq(users.email, employees.personalEmail)
      )
    )
    .where(and(...employeeFilters));
    
    // Get targeted employees
    const targetEmployees = await targetEmployeesQuery;
    
    // Create notification message
    const notificationMessage = `Announcement: ${announcement.title}\n${announcement.content.substring(0, 100)}${announcement.content.length > 100 ? '...' : ''}\nPosted by: ${authorName}`;
    
    // Send notifications to each employee
    for (const employee of targetEmployees) {
      if (employee.userId) {
        // Create in-app notification
        await notificationService.createNotification({
          userId: employee.userId,
          message: notificationMessage,
          channel: 'push',
          status: 'pending',
          data: {
            type: 'announcement',
            announcementId: announcement.id,
            title: announcement.title
          }
        });
      }
    }
  } catch (error) {
    console.error("Error notifying employees about announcement:", error);
  }
}

export default {
  createAnnouncement,
  getActiveAnnouncements,
  getDepartmentAnnouncements
};