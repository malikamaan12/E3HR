import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ObjectStorageService } from "./objectStorage";
import { BulkImportService } from "./services/bulkImport";
import { db } from "./db";
import { bulkImportJobs, leaves, employees, attendance, leaveTypes } from "@shared/schema";
import { eq, and, gte, lte, isNotNull, desc, sql } from 'drizzle-orm';
import notificationsRoutes from "./routes/notifications";
import announcementsRoutes from "./routes/announcements";
import slackRoutes from "./routes/slack";
import anthropicRoutes from "./routes/anthropic";
import { registerPerformanceRoutes } from "./routes/performance";
import reportingRoutes from "./routes/reporting";
import analyticsRoutes from "./routes/analytics";
import mobileRoutes from "./routes/mobile";
import roleManagementRoutes from "./routes/roleManagement";
import trainingRoutes from "./routes/training";
import authRoutes from "./routes/auth";
import dashboardRoutes from "./routes/dashboard";
import recruitmentRoutes from "./routes/recruitment";
import onboardingRoutes from "./routes/onboarding";
import employeeRoutes from "./routes/employee";
import cookieParser from "cookie-parser";
import { authenticate, logApiAccess } from "./middleware/auth";
import { addDataFiltering } from "./middleware/dataFilter";
import { 
  insertUserSchema, 
  insertEmployeeSchema, 
  insertDocumentSchema,
  insertAttendanceSchema,
  insertLeaveSchema,
  insertPayrollSchema,
  insertEventSchema,
  insertEventRoleSchema,
  insertEventStaffProfileSchema,
  insertEventRosterSchema,
  insertEventStaffAssignmentSchema,
  insertEventStaffPerformanceSchema,
  insertEventCommunicationSchema,
  insertEventCommunicationRecipientSchema,
  insertActivityLogSchema,
  insertShiftScheduleSchema,
  insertGeofenceSchema,
  insertLeaveTypeSchema,
  insertLeaveBalanceSchema,
  insertLeaveSupportingDocumentSchema,
  insertLeaveApprovalSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Add cookie parser middleware
  app.use(cookieParser());
  
  // Register auth routes
  app.use('/api/auth', authRoutes);
  
  // Register dashboard routes
  app.use('/api/dashboard', dashboardRoutes);
  
  // Register recruitment routes
  app.use('/api', authenticate, recruitmentRoutes);
  app.use('/api', authenticate, onboardingRoutes);
  
  // Register employee routes
  app.use('/api/employee', authenticate, employeeRoutes);
  
  // Use authentication middleware for API access logs
  app.use('/api', authenticate, logApiAccess);

  // User Routes
  app.get('/api/users/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      const userData = { ...user, password: undefined };
      res.status(200).json(userData);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting user', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/users', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const newUser = await storage.createUser(userData);
      const responseUser = { ...newUser, password: undefined };
      res.status(201).json(responseUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid user data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating user', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Employee Routes
  app.get('/api/employees', addDataFiltering('employee_database', 'read'), async (req: Request & { dataFilter?: any }, res: Response) => {
    try {
      const page = req.query.page ? parseInt(req.query.page as string) : 1;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const type = req.query.type as string | undefined;
      const user = req.user as any;

      let employees: any[] = [];
      
      // Apply role-based filtering
      if (req.dataFilter?.scope === 'self') {
        // Only return the user's own employee record
        const selfEmployee = await storage.getEmployeeByUserId(user.userId);
        employees = selfEmployee ? [selfEmployee] : [];
      } else if (req.dataFilter?.scope === 'department') {
        // Return employees in the same department
        const allEmployees = await storage.getEmployees(page, limit);
        employees = allEmployees.filter(emp => emp.department === user.department);
      } else if (req.dataFilter?.scope === 'event_staff') {
        // Return only temporary/event staff
        employees = await storage.getEmployeesByType('temporary', page, limit);
      } else if (req.dataFilter?.scope === 'all') {
        // Full access - return all employees
        if (type) {
          employees = await storage.getEmployeesByType(type, page, limit);
        } else {
          employees = await storage.getEmployees(page, limit);
        }
      } else {
        // No access
        employees = [];
      }

      res.status(200).json(employees);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting employees', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/employees/:id', addDataFiltering('employee_database', 'read'), async (req: Request & { dataFilter?: any }, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const user = req.user as any;
      
      // Check if user can access this specific employee
      const employee = await storage.getEmployee(id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Apply scope-based filtering
      if (req.dataFilter?.scope === 'self' && employee.userId !== user.userId) {
        return res.status(403).json({ message: 'Access denied: Can only view own profile' });
      }
      
      if (req.dataFilter?.scope === 'department' && employee.department !== user.department) {
        return res.status(403).json({ message: 'Access denied: Can only view employees in your department' });
      }
      
      if (req.dataFilter?.scope === 'event_staff' && employee.type !== 'temporary') {
        return res.status(403).json({ message: 'Access denied: Can only view event staff' });
      }
      
      res.status(200).json(employee);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting employee', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/employees', async (req: Request, res: Response) => {
    try {
      const employeeData = insertEmployeeSchema.parse(req.body);
      const newEmployee = await storage.createEmployee(employeeData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created employee record for ${newEmployee.firstName} ${newEmployee.lastName}`,
        entityType: 'employee',
        entityId: newEmployee.id
      });
      
      res.status(201).json(newEmployee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid employee data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating employee', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Update employee
  app.patch('/api/employees/:id', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.id);
      if (isNaN(employeeId)) {
        return res.status(400).json({ message: 'Invalid employee ID' });
      }
      
      // For PATCH, we only validate the fields that are being updated
      // Use partial schema for updates
      const updateSchema = insertEmployeeSchema.partial();
      const employeeData = updateSchema.parse(req.body);
      const updatedEmployee = await storage.updateEmployee(employeeId, employeeData);
      
      if (!updatedEmployee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'update',
        details: `Updated employee: ${updatedEmployee.firstName} ${updatedEmployee.lastName}`,
        entityType: 'employee',
        entityId: updatedEmployee.id
      });
      
      res.status(200).json(updatedEmployee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid employee data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error updating employee', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Document Routes
  app.get('/api/employees/:id/documents', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.id);
      const documents = await storage.getDocuments(employeeId);
      res.status(200).json(documents);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting documents', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/documents', async (req: Request, res: Response) => {
    try {
      // Check content type to handle both FormData and JSON submissions
      if (req.headers['content-type']?.includes('multipart/form-data')) {
        // TODO: For future implementation of file upload handling
        // We would use a middleware like multer to handle the file upload
        // For now, we'll return an error since we don't have the middleware set up
        return res.status(400).json({ 
          message: 'File upload not currently supported via FormData. Please use the JSON API.' 
        });
      }
      
      // Handle JSON submissions
      const documentData = insertDocumentSchema.parse(req.body);
      const newDocument = await storage.createDocument(documentData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Added ${newDocument.documentType} document`,
        entityType: 'document',
        entityId: newDocument.id
      });
      
      res.status(201).json(newDocument);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid document data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating document', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/documents/expiring', async (req: Request, res: Response) => {
    try {
      const days = req.query.days ? parseInt(req.query.days as string) : 30;
      const expiringDocuments = await storage.getExpiringDocuments(days);
      res.status(200).json(expiringDocuments);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting expiring documents', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/documents', async (req: Request, res: Response) => {
    try {
      // Simply get documents without joining employee names since the employees table doesn't have those columns
      const query = `
        SELECT * FROM documents
        ORDER BY created_at DESC
      `;
      
      const result = await storage.pool.query(query);
      
      // Map through results to add a placeholder for employee name
      const docsWithEmployeeNames = result.rows.map(doc => ({
        ...doc,
        employee_name: `Employee #${doc.employee_id}`
      }));
      
      res.status(200).json(docsWithEmployeeNames);
    } catch (error) {
      console.error('Error getting all documents:', error);
      res.status(500).json({ message: 'Server error getting documents', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/documents/:id', async (req: Request, res: Response) => {
    try {
      const documentId = parseInt(req.params.id);
      if (isNaN(documentId)) {
        return res.status(400).json({ message: 'Invalid document ID' });
      }
      
      // Get document without joining employee name
      const query = `
        SELECT * FROM documents
        WHERE id = $1
      `;
      
      const result = await storage.pool.query(query, [documentId]);
      
      if (result.rows.length === 0) {
        return res.status(404).json({ message: 'Document not found' });
      }
      
      // Add placeholder employee name
      const document = {
        ...result.rows[0],
        employee_name: `Employee #${result.rows[0].employee_id}`
      };
      
      res.status(200).json(document);
    } catch (error) {
      console.error('Error getting document:', error);
      res.status(500).json({ message: 'Server error getting document', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Attendance Routes
  app.post('/api/attendance', async (req: Request, res: Response) => {
    try {
      const attendanceData = insertAttendanceSchema.parse(req.body);
      
      // Check if attendance record already exists for this employee and date
      const existingAttendance = await storage.getAttendanceByEmployeeAndDate(
        attendanceData.employeeId, 
        new Date(attendanceData.date)
      );
      
      if (existingAttendance) {
        // Update existing record
        const updatedAttendance = await storage.updateAttendance(existingAttendance.id, attendanceData);
        return res.status(200).json(updatedAttendance);
      }
      
      // Create new record
      const newAttendance = await storage.createAttendance(attendanceData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Recorded attendance for employee #${newAttendance.employeeId}`,
        entityType: 'attendance',
        entityId: newAttendance.id
      });
      
      res.status(201).json(newAttendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid attendance data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error recording attendance', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/attendance/date/:date', async (req: Request, res: Response) => {
    try {
      const date = new Date(req.params.date);
      if (isNaN(date.getTime())) {
        return res.status(400).json({ message: 'Invalid date format' });
      }
      
      const attendanceRecords = await storage.getAttendanceByDate(date);
      res.status(200).json(attendanceRecords);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting attendance records', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get today's attendance for current user
  app.get('/api/attendance/today', async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user?.userId;
      if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
      }

      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(userId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      const today = new Date();
      const todayRecord = await storage.getAttendanceByEmployeeAndDate(employee.id, today);
      res.status(200).json(todayRecord || null);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting today\'s attendance', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Clock status endpoint (for UI checks)
  app.get('/api/attendance/clock-in', async (req: Request, res: Response) => {
    res.status(200).json({ message: 'Use POST method to clock in' });
  });

  // Clock-in endpoint
  app.post('/api/attendance/clock-in', async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user?.userId;
      if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
      }

      const { location, notes } = req.body;
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(userId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      // Check if already clocked in today
      const existingAttendance = await storage.getAttendanceByEmployeeAndDate(employee.id, today);
      
      if (existingAttendance && existingAttendance.checkIn) {
        return res.status(400).json({ 
          message: 'Already clocked in for today',
          attendance: existingAttendance
        });
      }

      // Create or update attendance record
      const attendanceData = {
        employeeId: employee.id,
        date: today.toISOString().split('T')[0],
        checkIn: now, // Pass Date object, not string
        checkInMethod: 'manual' as any,
        status: 'present' as any,
        location: location || null,
        notes: notes || null
      };

      let result;
      if (existingAttendance) {
        result = await storage.updateAttendance(existingAttendance.id, attendanceData);
      } else {
        result = await storage.createAttendance(attendanceData);
      }

      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ message: 'Server error during clock-in', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Clock-out status endpoint (for UI checks)  
  app.get('/api/attendance/clock-out', async (req: Request, res: Response) => {
    res.status(200).json({ message: 'Use POST method to clock out' });
  });

  // Clock-out endpoint
  app.post('/api/attendance/clock-out', async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user?.userId;
      if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
      }

      const { location, notes } = req.body;
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(userId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      // Find today's attendance record
      const existingAttendance = await storage.getAttendanceByEmployeeAndDate(employee.id, today);
      if (!existingAttendance || !existingAttendance.checkIn) {
        return res.status(400).json({ 
          message: 'No active clock-in found for today. Please clock in first.'
        });
      }

      if (existingAttendance.checkOut) {
        return res.status(400).json({ 
          message: 'Already clocked out for today',
          attendance: existingAttendance
        });
      }

      // Calculate hours worked (stored in minutes)
      const checkInTime = new Date(existingAttendance.checkIn);
      const checkOutTime = now;
      const hoursWorkedMinutes = Math.round((checkOutTime.getTime() - checkInTime.getTime()) / (1000 * 60));

      // Update attendance record
      const updateData = {
        checkOut: now, // Pass Date object, not string
        checkOutMethod: 'manual',
        totalWorkHours: hoursWorkedMinutes, // Store in minutes as per schema
        location: location || existingAttendance.location,
        notes: notes ? `${existingAttendance.notes || ''}${existingAttendance.notes ? '; ' : ''}${notes}` : existingAttendance.notes
      };

      const result = await storage.updateAttendance(existingAttendance.id, updateData);
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ message: 'Server error during clock-out', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Break start endpoint
  app.post('/api/attendance/clock-break_start', async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user?.userId;
      if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
      }

      const { location, notes } = req.body;
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(userId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      // Find today's attendance record
      const existingAttendance = await storage.getAttendanceByEmployeeAndDate(employee.id, today);
      if (!existingAttendance || !existingAttendance.checkIn) {
        return res.status(400).json({ 
          message: 'Please clock in first before taking a break.'
        });
      }

      if (existingAttendance.checkOut) {
        return res.status(400).json({ 
          message: 'Cannot start break after clocking out.'
        });
      }

      if (existingAttendance.breakStartTime && !existingAttendance.breakEndTime) {
        return res.status(400).json({ 
          message: 'Break already started. Please end current break first.'
        });
      }

      // Update attendance record with break start time
      const updateData = {
        breakStartTime: now, // Pass Date object, not string
        breakEndTime: null,
        notes: notes ? `${existingAttendance.notes || ''}${existingAttendance.notes ? '; ' : ''}Break started: ${notes}` : existingAttendance.notes
      };

      const result = await storage.updateAttendance(existingAttendance.id, updateData);
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ message: 'Server error starting break', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Break end endpoint
  app.post('/api/attendance/clock-break_end', async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user?.userId;
      if (!userId) {
        return res.status(401).json({ message: 'User not authenticated' });
      }

      const { location, notes } = req.body;
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(userId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      // Find today's attendance record
      const existingAttendance = await storage.getAttendanceByEmployeeAndDate(employee.id, today);
      if (!existingAttendance || !existingAttendance.checkIn) {
        return res.status(400).json({ 
          message: 'Please clock in first.'
        });
      }

      if (!existingAttendance.breakStartTime || existingAttendance.breakEndTime) {
        return res.status(400).json({ 
          message: 'No active break found to end.'
        });
      }

      // Update attendance record with break end time
      const updateData = {
        breakEndTime: now, // Pass Date object, not string
        notes: notes ? `${existingAttendance.notes || ''}${existingAttendance.notes ? '; ' : ''}Break ended: ${notes}` : existingAttendance.notes
      };

      const result = await storage.updateAttendance(existingAttendance.id, updateData);
      res.status(200).json(result);
    } catch (error) {
      res.status(500).json({ message: 'Server error ending break', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Leave Routes
  app.post('/api/leaves', async (req: Request, res: Response) => {
    try {
      const leaveData = insertLeaveSchema.parse(req.body);
      const newLeave = await storage.createLeave(leaveData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Leave request submitted by employee #${newLeave.employeeId}`,
        entityType: 'leave',
        entityId: newLeave.id
      });
      
      res.status(201).json(newLeave);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid leave data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error submitting leave request', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/leaves/pending', async (req: Request, res: Response) => {
    try {
      const pendingLeaves = await storage.getPendingLeaves();
      res.status(200).json(pendingLeaves);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting pending leaves', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.patch('/api/leaves/:id/status', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { status, approvedBy } = req.body;
      
      if (!['approved', 'rejected', 'cancelled'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }
      
      const updatedLeave = await storage.updateLeaveStatus(id, status, approvedBy);
      if (!updatedLeave) {
        return res.status(404).json({ message: 'Leave request not found' });
      }
      
      // Log activity
      await storage.createActivityLog({
        userId: approvedBy || null,
        action: 'update',
        details: `Leave request #${id} ${status}`,
        entityType: 'leave',
        entityId: id
      });
      
      res.status(200).json(updatedLeave);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating leave status', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // New Leave API Routes
  
  app.get('/api/leaves/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const leave = await storage.getLeave(id);
      
      if (!leave) {
        return res.status(404).json({ message: 'Leave request not found' });
      }
      
      res.status(200).json(leave);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leave details', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/employees/:employeeId/leaves', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const leaves = await storage.getLeaves(employeeId);
      res.status(200).json(leaves);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting employee leaves', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Get all leaves endpoint
  app.get('/api/leaves', async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user?.userId;
      
      // Get all leaves - simplified query without join
      const allLeaves = await db.select()
      .from(leaves)
      .orderBy(desc(leaves.createdAt));

      // Format the response - simplified without employee join
      const formattedLeaves = allLeaves.map(leave => ({
        id: leave.id,
        employeeId: leave.employeeId,
        leaveType: leave.leaveType,
        startDate: leave.startDate,
        endDate: leave.endDate,
        totalDays: leave.totalDays,
        reason: leave.reason,
        status: leave.status,
        approvedBy: leave.approvedBy,
        approvedAt: leave.approvedAt,
        createdAt: leave.createdAt,
        updatedAt: leave.updatedAt,
        employee: {
          id: leave.employeeId,
          firstName: 'Employee',
          lastName: String(leave.employeeId),
          department: 'HR',
          position: 'Staff',
        },
        leaveType: {
          id: 1,
          name: leave.leaveType,
        }
      }));

      res.status(200).json(formattedLeaves);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leaves', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/leaves/status/:status', async (req: Request, res: Response) => {
    try {
      const status = req.params.status;
      
      // Get leaves for the specified status - simplified query
      const leavesList = await db.select()
      .from(leaves)
      .where(eq(leaves.status, status))
      .orderBy(desc(leaves.createdAt));

      // Format the response - simplified without employee join
      const formattedLeaves = leavesList.map(leave => ({
        id: leave.id,
        employeeId: leave.employeeId,
        leaveType: leave.leaveType,
        startDate: leave.startDate,
        endDate: leave.endDate,
        totalDays: leave.totalDays,
        reason: leave.reason,
        status: leave.status,
        approvedBy: leave.approvedBy,
        approvedAt: leave.approvedAt,
        createdAt: leave.createdAt,
        updatedAt: leave.updatedAt,
        employee: {
          id: leave.employeeId,
          firstName: 'Employee',
          lastName: String(leave.employeeId),
          department: 'HR',
          position: 'Staff',
        },
        leaveType: {
          id: 1,
          name: leave.leaveType,
        }
      }));

      res.status(200).json(formattedLeaves);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leaves by status', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/employees/:employeeId/leaves/date-range', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const startDate = new Date(req.query.startDate as string);
      const endDate = new Date(req.query.endDate as string);
      
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ message: 'Invalid date format' });
      }
      
      const leaves = await storage.getLeavesByDateRange(employeeId, startDate, endDate);
      res.status(200).json(leaves);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leaves by date range', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Leave Types API Routes
  
  app.get('/api/leave-types', async (req: Request, res: Response) => {
    try {
      const leaveTypes = await storage.getLeaveTypes();
      res.status(200).json(leaveTypes);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leave types', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/leave-types/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const leaveType = await storage.getLeaveType(id);
      
      if (!leaveType) {
        return res.status(404).json({ message: 'Leave type not found' });
      }
      
      res.status(200).json(leaveType);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leave type details', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/leave-types', async (req: Request, res: Response) => {
    try {
      const leaveTypeData = insertLeaveTypeSchema.parse(req.body);
      const newLeaveType = await storage.createLeaveType(leaveTypeData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created new leave type: ${newLeaveType.name}`,
        entityType: 'leave_type',
        entityId: newLeaveType.id
      });
      
      res.status(201).json(newLeaveType);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid leave type data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating leave type', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.patch('/api/leave-types/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const leaveTypeData = req.body;
      
      // Check if the leave type exists
      const leaveType = await storage.getLeaveType(id);
      if (!leaveType) {
        return res.status(404).json({ message: 'Leave type not found' });
      }
      
      const updatedLeaveType = await storage.updateLeaveType(id, leaveTypeData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'update',
        details: `Updated leave type: ${leaveType.name}`,
        entityType: 'leave_type',
        entityId: id
      });
      
      res.status(200).json(updatedLeaveType);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid leave type data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error updating leave type', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Leave Balances API Routes
  
  app.get('/api/employees/:employeeId/leave-balances', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const leaveBalances = await storage.getLeaveBalances(employeeId);
      res.status(200).json(leaveBalances);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting employee leave balances', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/leave-balances/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const leaveBalance = await storage.getLeaveBalance(id);
      
      if (!leaveBalance) {
        return res.status(404).json({ message: 'Leave balance not found' });
      }
      
      res.status(200).json(leaveBalance);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leave balance details', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/leave-balances', async (req: Request, res: Response) => {
    try {
      const leaveBalanceData = insertLeaveBalanceSchema.parse(req.body);
      const newLeaveBalance = await storage.createLeaveBalance(leaveBalanceData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created leave balance for employee #${newLeaveBalance.employeeId}, leave type #${newLeaveBalance.leaveTypeId}`,
        entityType: 'leave_balance',
        entityId: newLeaveBalance.id
      });
      
      res.status(201).json(newLeaveBalance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid leave balance data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating leave balance', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.patch('/api/leave-balances/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const leaveBalanceData = req.body;
      
      // Check if the leave balance exists
      const leaveBalance = await storage.getLeaveBalance(id);
      if (!leaveBalance) {
        return res.status(404).json({ message: 'Leave balance not found' });
      }
      
      const updatedLeaveBalance = await storage.updateLeaveBalance(id, leaveBalanceData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'update',
        details: `Updated leave balance for employee #${leaveBalance.employeeId}, leave type #${leaveBalance.leaveTypeId}`,
        entityType: 'leave_balance',
        entityId: id
      });
      
      res.status(200).json(updatedLeaveBalance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid leave balance data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error updating leave balance', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Leave Supporting Documents API Routes
  
  app.get('/api/leaves/:leaveId/supporting-documents', async (req: Request, res: Response) => {
    try {
      const leaveId = parseInt(req.params.leaveId);
      const documents = await storage.getLeaveSupportingDocuments(leaveId);
      res.status(200).json(documents);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leave supporting documents', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/leave-supporting-documents', async (req: Request, res: Response) => {
    try {
      const documentData = insertLeaveSupportingDocumentSchema.parse(req.body);
      const newDocument = await storage.createLeaveSupportingDocument(documentData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Uploaded supporting document for leave request #${newDocument.leaveId}`,
        entityType: 'leave_supporting_document',
        entityId: newDocument.id
      });
      
      res.status(201).json(newDocument);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid document data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error uploading leave supporting document', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Leave Approvals API Routes
  
  app.get('/api/leaves/:leaveId/approvals', async (req: Request, res: Response) => {
    try {
      const leaveId = parseInt(req.params.leaveId);
      const approvals = await storage.getLeaveApprovals(leaveId);
      res.status(200).json(approvals);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting leave approvals', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/leave-approvals', async (req: Request, res: Response) => {
    try {
      const approvalData = insertLeaveApprovalSchema.parse(req.body);
      const newApproval = await storage.createLeaveApproval(approvalData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Added approval for leave request #${newApproval.leaveId} by approver #${newApproval.approverId}`,
        entityType: 'leave_approval',
        entityId: newApproval.id
      });
      
      res.status(201).json(newApproval);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid approval data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating leave approval', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Payroll Routes
  app.post('/api/payroll', async (req: Request, res: Response) => {
    try {
      const payrollData = insertPayrollSchema.parse(req.body);
      
      // Check if payroll record already exists for this employee, month and year
      const existingPayroll = await storage.getPayroll(
        payrollData.employeeId,
        payrollData.month,
        payrollData.year
      );
      
      if (existingPayroll) {
        return res.status(400).json({ 
          message: 'Payroll record already exists for this employee in the specified month and year' 
        });
      }
      
      const newPayroll = await storage.createPayroll(payrollData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created payroll record for employee #${newPayroll.employeeId} for ${newPayroll.month}/${newPayroll.year}`,
        entityType: 'payroll',
        entityId: newPayroll.id
      });
      
      res.status(201).json(newPayroll);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid payroll data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating payroll record', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/payroll/month/:month/year/:year', addDataFiltering('payroll_management', 'read'), async (req: Request & { dataFilter?: any }, res: Response) => {
    try {
      const month = parseInt(req.params.month);
      const year = parseInt(req.params.year);
      const user = req.user as any;
      
      if (isNaN(month) || month < 1 || month > 12 || isNaN(year)) {
        return res.status(400).json({ message: 'Invalid month or year' });
      }
      
      let payrollRecords: any[] = [];
      
      // Apply role-based filtering
      if (req.dataFilter?.scope === 'self') {
        // Only return the user's own payroll record
        const employee = await storage.getEmployeeByUserId(user.userId);
        if (employee) {
          const record = await storage.getPayroll(employee.id, month, year);
          payrollRecords = record ? [record] : [];
        }
      } else if (req.dataFilter?.scope === 'department') {
        // Return payroll for employees in the same department
        const allRecords = await storage.getPayrollsByMonth(month, year);
        const deptEmployees = (await storage.getEmployees(1, 1000)).filter(e => e.department === user.department);
        const deptEmployeeIds = deptEmployees.map(e => e.id);
        payrollRecords = allRecords.filter(r => deptEmployeeIds.includes(r.employeeId));
      } else if (req.dataFilter?.scope === 'all') {
        // Full access - return all payroll records
        payrollRecords = await storage.getPayrollsByMonth(month, year);
      } else {
        // No access
        payrollRecords = [];
      }
      
      res.status(200).json(payrollRecords);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting payroll records', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Event Routes
  app.post('/api/events', async (req: Request, res: Response) => {
    try {
      const eventData = insertEventSchema.parse(req.body);
      const newEvent = await storage.createEvent(eventData);
      
      // Log activity
      await storage.createActivityLog({
        userId: eventData.createdBy,
        action: 'create',
        details: `Created new event: ${newEvent.name}`,
        entityType: 'event',
        entityId: newEvent.id
      });
      
      res.status(201).json(newEvent);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid event data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating event', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/events', async (req: Request, res: Response) => {
    try {
      const status = req.query.status as string | undefined;
      const events = await storage.getEvents(status);
      res.status(200).json(events);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting events', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Event Staff Assignment Routes
  app.post('/api/event-staff-assignments', async (req: Request, res: Response) => {
    try {
      const assignmentData = insertEventStaffAssignmentSchema.parse(req.body);
      const newAssignment = await storage.createEventStaffAssignment(assignmentData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Assigned employee #${newAssignment.employeeId} to event #${newAssignment.eventId}`,
        entityType: 'event_staff_assignment',
        entityId: newAssignment.id
      });
      
      res.status(201).json(newAssignment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid assignment data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating staff assignment', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/events/:id/staff', async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.id);
      const assignments = await storage.getEventStaffAssignments(eventId);
      res.status(200).json(assignments);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event staff assignments', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/event-staff-assignments', async (req: Request, res: Response) => {
    try {
      // Get all assignments - we'll filter on the client side if needed
      const assignments = await storage.getEventStaffAssignments(0);
      res.status(200).json(assignments);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting staff assignments', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/events/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const event = await storage.getEvent(id);
      
      if (!event) {
        return res.status(404).json({ message: 'Event not found' });
      }
      
      res.status(200).json(event);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event details', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.patch('/api/events/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updateSchema = insertEventSchema.partial();
      const eventData = updateSchema.parse(req.body);
      const updatedEvent = await storage.updateEvent(id, eventData);
      
      if (!updatedEvent) {
        return res.status(404).json({ message: 'Event not found' });
      }
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'update',
        details: `Updated event: ${updatedEvent.name}`,
        entityType: 'event',
        entityId: id
      });
      
      res.status(200).json(updatedEvent);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid event data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error updating event', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Event Roles Routes
  app.get('/api/event-roles', async (req: Request, res: Response) => {
    try {
      const eventId = req.query.eventId ? parseInt(req.query.eventId as string) : undefined;
      const roles = await storage.getEventRoles(eventId);
      res.status(200).json(roles);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event roles', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/event-roles/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const role = await storage.getEventRole(id);
      
      if (!role) {
        return res.status(404).json({ message: 'Event role not found' });
      }
      
      res.status(200).json(role);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event role details', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/event-roles', async (req: Request, res: Response) => {
    try {
      const roleData = insertEventRoleSchema.parse(req.body);
      const newRole = await storage.createEventRole(roleData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created new event role: ${newRole.roleName} for event #${newRole.eventId}`,
        entityType: 'event_role',
        entityId: newRole.id
      });
      
      res.status(201).json(newRole);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid event role data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating event role', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Event Staff Profiles Routes
  app.get('/api/event-staff-profiles', async (req: Request, res: Response) => {
    try {
      const profiles = await storage.getEventStaffProfiles();
      res.status(200).json(profiles);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event staff profiles', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/employees/:employeeId/event-staff-profile', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const profile = await storage.getEventStaffProfileByEmployeeId(employeeId);
      
      if (!profile) {
        return res.status(404).json({ message: 'Event staff profile not found' });
      }
      
      res.status(200).json(profile);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event staff profile', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/event-staff-profiles', async (req: Request, res: Response) => {
    try {
      const profileData = insertEventStaffProfileSchema.parse(req.body);
      const newProfile = await storage.createEventStaffProfile(profileData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created event staff profile for employee #${newProfile.employeeId}`,
        entityType: 'event_staff_profile',
        entityId: newProfile.id
      });
      
      res.status(201).json(newProfile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid staff profile data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating staff profile', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Event Rosters Routes
  app.get('/api/events/:eventId/rosters', async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const rosters = await storage.getEventRosters(eventId);
      res.status(200).json(rosters);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event rosters', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/event-rosters/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const roster = await storage.getEventRoster(id);
      
      if (!roster) {
        return res.status(404).json({ message: 'Event roster not found' });
      }
      
      res.status(200).json(roster);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting event roster details', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/event-rosters', async (req: Request, res: Response) => {
    try {
      const rosterData = insertEventRosterSchema.parse(req.body);
      const newRoster = await storage.createEventRoster(rosterData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created new roster for event #${newRoster.eventId}: ${newRoster.title}`,
        entityType: 'event_roster',
        entityId: newRoster.id
      });
      
      res.status(201).json(newRoster);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid roster data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating event roster', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/event-rosters/:rosterId/assignments', async (req: Request, res: Response) => {
    try {
      const rosterId = parseInt(req.params.rosterId);
      const assignments = await storage.getEventRosterAssignments(rosterId);
      res.status(200).json(assignments);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting roster assignments', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Event Staff Performance Routes
  app.get('/api/event-staff-performance', async (req: Request, res: Response) => {
    try {
      const eventId = req.query.eventId ? parseInt(req.query.eventId as string) : undefined;
      const employeeId = req.query.employeeId ? parseInt(req.query.employeeId as string) : undefined;
      
      const performances = await storage.getEventStaffPerformances(eventId, employeeId);
      res.status(200).json(performances);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting performance records', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/event-staff-performance', async (req: Request, res: Response) => {
    try {
      const performanceData = insertEventStaffPerformanceSchema.parse(req.body);
      const newPerformance = await storage.createEventStaffPerformance(performanceData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Recorded performance for employee #${newPerformance.employeeId} at event #${newPerformance.eventId}`,
        entityType: 'event_staff_performance',
        entityId: newPerformance.id
      });
      
      res.status(201).json(newPerformance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid performance data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error recording performance', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  // Event Communications Routes
  app.get('/api/events/:eventId/communications', async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const communications = await storage.getEventCommunications(eventId);
      res.status(200).json(communications);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting communications', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/event-communications', async (req: Request, res: Response) => {
    try {
      const communicationData = insertEventCommunicationSchema.parse(req.body);
      const newCommunication = await storage.createEventCommunication(communicationData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Sent communication for event #${newCommunication.eventId}: ${newCommunication.subject}`,
        entityType: 'event_communication',
        entityId: newCommunication.id
      });
      
      res.status(201).json(newCommunication);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid communication data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error sending communication', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.get('/api/event-communications/:communicationId/recipients', async (req: Request, res: Response) => {
    try {
      const communicationId = parseInt(req.params.communicationId);
      const recipients = await storage.getEventCommunicationRecipients(communicationId);
      res.status(200).json(recipients);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting communication recipients', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });
  
  app.post('/api/event-communication-recipients', async (req: Request, res: Response) => {
    try {
      const recipientData = insertEventCommunicationRecipientSchema.parse(req.body);
      const newRecipient = await storage.createEventCommunicationRecipient(recipientData);
      res.status(201).json(newRecipient);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid recipient data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error adding communication recipient', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Shift Schedule Routes
  app.post('/api/shift-schedules', async (req: Request, res: Response) => {
    try {
      const shiftScheduleData = insertShiftScheduleSchema.parse(req.body);
      const newShiftSchedule = await storage.createShiftSchedule(shiftScheduleData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created shift schedule for employee #${newShiftSchedule.employeeId} on ${newShiftSchedule.date}`,
        entityType: 'shift_schedule',
        entityId: newShiftSchedule.id
      });
      
      res.status(201).json(newShiftSchedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid shift schedule data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating shift schedule', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/shift-schedules', async (req: Request, res: Response) => {
    try {
      let date: Date | undefined;
      
      if (req.query.date) {
        date = new Date(req.query.date as string);
        if (isNaN(date.getTime())) {
          return res.status(400).json({ message: 'Invalid date format' });
        }
      }
      
      const shiftSchedules = await storage.getShiftSchedules(date);
      res.status(200).json(shiftSchedules);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting shift schedules', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/employees/:id/shift-schedules', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.id);
      let startDate: Date | undefined;
      let endDate: Date | undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
        if (isNaN(startDate.getTime())) {
          return res.status(400).json({ message: 'Invalid startDate format' });
        }
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
        if (isNaN(endDate.getTime())) {
          return res.status(400).json({ message: 'Invalid endDate format' });
        }
      }
      
      const shiftSchedules = await storage.getEmployeeShiftSchedules(employeeId, startDate, endDate);
      res.status(200).json(shiftSchedules);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting employee shift schedules', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.patch('/api/shift-schedules/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      // Partial validation - only validate the fields that are provided
      const validFields = Object.keys(insertShiftScheduleSchema.shape).filter(key => key in req.body);
      const validationSchema = z.object(
        Object.fromEntries(validFields.map(key => [key, insertShiftScheduleSchema.shape[key]]))
      );
      
      const updateData = validationSchema.parse(req.body);
      const updatedShiftSchedule = await storage.updateShiftSchedule(id, updateData);
      
      if (!updatedShiftSchedule) {
        return res.status(404).json({ message: 'Shift schedule not found' });
      }
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'update',
        details: `Updated shift schedule #${id}`,
        entityType: 'shift_schedule',
        entityId: id
      });
      
      res.status(200).json(updatedShiftSchedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid shift schedule data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error updating shift schedule', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.delete('/api/shift-schedules/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      // First check if the shift schedule exists
      const shiftSchedule = await storage.getShiftSchedule(id);
      if (!shiftSchedule) {
        return res.status(404).json({ message: 'Shift schedule not found' });
      }
      
      await storage.deleteShiftSchedule(id);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'delete',
        details: `Deleted shift schedule #${id}`,
        entityType: 'shift_schedule',
        entityId: id
      });
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Server error deleting shift schedule', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Geofence Routes
  app.post('/api/geofences', async (req: Request, res: Response) => {
    try {
      const geofenceData = insertGeofenceSchema.parse(req.body);
      const newGeofence = await storage.createGeofence(geofenceData);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'create',
        details: `Created geofence: ${newGeofence.geofenceName}`,
        entityType: 'geofence',
        entityId: newGeofence.id
      });
      
      res.status(201).json(newGeofence);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid geofence data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error creating geofence', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/geofences', async (req: Request, res: Response) => {
    try {
      let active: boolean | undefined;
      
      if (req.query.active !== undefined) {
        active = req.query.active === 'true';
      }
      
      const geofences = await storage.getGeofences(active);
      res.status(200).json(geofences);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting geofences', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/geofences/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const geofence = await storage.getGeofence(id);
      
      if (!geofence) {
        return res.status(404).json({ message: 'Geofence not found' });
      }
      
      res.status(200).json(geofence);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting geofence', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/geofences/lookup/:geofenceId', async (req: Request, res: Response) => {
    try {
      const geofenceId = req.params.geofenceId;
      const geofence = await storage.getGeofenceByGeofenceId(geofenceId);
      
      if (!geofence) {
        return res.status(404).json({ message: 'Geofence not found' });
      }
      
      res.status(200).json(geofence);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting geofence', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.patch('/api/geofences/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      // Partial validation - only validate the fields that are provided
      const validFields = Object.keys(insertGeofenceSchema.shape).filter(key => key in req.body);
      const validationSchema = z.object(
        Object.fromEntries(validFields.map(key => [key, insertGeofenceSchema.shape[key]]))
      );
      
      const updateData = validationSchema.parse(req.body);
      const updatedGeofence = await storage.updateGeofence(id, updateData);
      
      if (!updatedGeofence) {
        return res.status(404).json({ message: 'Geofence not found' });
      }
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'update',
        details: `Updated geofence: ${updatedGeofence.geofenceName}`,
        entityType: 'geofence',
        entityId: id
      });
      
      res.status(200).json(updatedGeofence);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid geofence data', error: error.errors });
      }
      res.status(500).json({ message: 'Server error updating geofence', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.delete('/api/geofences/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      // First check if the geofence exists
      const geofence = await storage.getGeofence(id);
      if (!geofence) {
        return res.status(404).json({ message: 'Geofence not found' });
      }
      
      await storage.deleteGeofence(id);
      
      // Log activity
      await storage.createActivityLog({
        userId: req.body.userId || null,
        action: 'delete',
        details: `Deleted geofence: ${geofence.geofenceName}`,
        entityType: 'geofence',
        entityId: id
      });
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Server error deleting geofence', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Communication Hub Routes
  app.use('/api/notifications', notificationsRoutes);
  app.use('/api/announcements', announcementsRoutes);
  app.use('/api/slack', slackRoutes);
  app.use('/api/anthropic', anthropicRoutes);

  // Performance Management Routes
  registerPerformanceRoutes(app);
  
  // Reports & Analytics Routes
  app.use('/api/reporting', reportingRoutes);
  app.use('/api/analytics', analyticsRoutes);
  
  // Mobile API Routes
  app.use('/api/mobile', mobileRoutes);
  
  // Role & Permission Management Routes
  app.use('/api/role-management', roleManagementRoutes);
  
  // Training & Skills Routes
  app.use('/api/training', trainingRoutes);

  // Initialize services
  const objectStorageService = new ObjectStorageService();
  const bulkImportService = new BulkImportService();

  // Bulk Import API endpoints
  
  // Get upload URL for bulk import file
  app.post("/api/bulk-import/upload-url", async (req, res) => {
    try {
      const uploadURL = await objectStorageService.getObjectEntityUploadURL();
      res.json({ uploadURL });
    } catch (error: any) {
      console.error("Error getting upload URL:", error);
      res.status(500).json({ error: "Failed to get upload URL" });
    }
  });

  // Create bulk import job
  app.post("/api/bulk-import/create-job", async (req, res) => {
    try {
      const { fileName, fileUrl } = req.body;
      const userId = req.user?.userId;

      if (!fileName || !fileUrl) {
        return res.status(400).json({ error: "fileName and fileUrl are required" });
      }

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Create import job record
      const [job] = await db.insert(bulkImportJobs).values({
        fileName,
        fileUrl,
        uploadedBy: userId,
        status: "processing",
      }).returning();

      // Start processing in background (you might want to use a queue system in production)
      setTimeout(async () => {
        try {
          // Download file content
          const response = await fetch(fileUrl);
          const csvContent = await response.text();
          
          // Process the bulk import
          await bulkImportService.processBulkImport(job.id, csvContent, userId);
        } catch (error) {
          console.error("Bulk import processing failed:", error);
        }
      }, 1000);

      res.json({ 
        success: true, 
        jobId: job.id,
        message: "Bulk import job created successfully"
      });
    } catch (error: any) {
      console.error("Error creating bulk import job:", error);
      res.status(500).json({ error: "Failed to create bulk import job" });
    }
  });

  // Get bulk import job status
  app.get("/api/bulk-import/job/:jobId", async (req, res) => {
    try {
      const jobId = parseInt(req.params.jobId);
      const job = await bulkImportService.getImportJob(jobId);

      if (!job) {
        return res.status(404).json({ error: "Job not found" });
      }

      res.json(job);
    } catch (error: any) {
      console.error("Error getting bulk import job:", error);
      res.status(500).json({ error: "Failed to get job status" });
    }
  });

  // Get all bulk import jobs for user
  app.get("/api/bulk-import/jobs", async (req, res) => {
    try {
      const userId = req.user?.userId;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const jobs = await bulkImportService.getImportJobs(userId);
      res.json(jobs);
    } catch (error: any) {
      console.error("Error getting bulk import jobs:", error);
      res.status(500).json({ error: "Failed to get jobs" });
    }
  });

  // Download sample CSV template
  app.get("/api/bulk-import/template", (req, res) => {
    const csvTemplate = `firstName,lastName,email,gender,dateOfBirth,nationality,qidNumber,primaryMobile,residentialAddress,emergencyContactName,emergencyContactNumber,department,position,location,joiningDate,type,username,role
John,Smith,john.smith@company.com,male,1990-05-15,American,12345678901,+97412345678,"123 Main St, Doha",Jane Smith,+97412345679,IT,Software Developer,Doha Office,2024-01-15,permanent,jsmith,employee
Sarah,Johnson,sarah.johnson@company.com,female,1988-03-20,British,12345678902,+97412345680,"456 Oak Ave, Doha",Mark Johnson,+97412345681,HR,HR Manager,Doha Office,2024-02-01,permanent,sjohnson,hr`;

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="employee_import_template.csv"');
    res.send(csvTemplate);
  });

  // Activity Log Routes
  app.get('/api/activity-logs/recent', async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const activityLogs = await storage.getRecentActivityLogs(limit);
      res.status(200).json(activityLogs);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting activity logs', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Recruitment APIs
  app.get('/api/job-requisitions', async (req: Request, res: Response) => {
    try {
      const status = req.query.status as string | undefined;
      const requisitions = await storage.getJobRequisitions(status);
      res.status(200).json(requisitions);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting job requisitions', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/job-requisitions/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const requisition = await storage.getJobRequisition(id);
      if (!requisition) {
        return res.status(404).json({ message: 'Job requisition not found' });
      }
      res.status(200).json(requisition);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting job requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/job-requisitions', async (req: Request, res: Response) => {
    try {
      const requisition = await storage.createJobRequisition(req.body);
      res.status(201).json(requisition);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating job requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/job-requisitions/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedRequisition = await storage.updateJobRequisition(id, req.body);
      if (!updatedRequisition) {
        return res.status(404).json({ message: 'Job requisition not found' });
      }
      res.status(200).json(updatedRequisition);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating job requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/candidates', async (req: Request, res: Response) => {
    try {
      const search = req.query.search as string | undefined;
      const candidates = await storage.getCandidates(search);
      res.status(200).json(candidates);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting candidates', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/candidates/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const candidate = await storage.getCandidate(id);
      if (!candidate) {
        return res.status(404).json({ message: 'Candidate not found' });
      }
      res.status(200).json(candidate);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting candidate', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/candidates', async (req: Request, res: Response) => {
    try {
      const candidate = await storage.createCandidate(req.body);
      res.status(201).json(candidate);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating candidate', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/candidates/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedCandidate = await storage.updateCandidate(id, req.body);
      if (!updatedCandidate) {
        return res.status(404).json({ message: 'Candidate not found' });
      }
      res.status(200).json(updatedCandidate);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating candidate', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/job-applications', async (req: Request, res: Response) => {
    try {
      const requisitionId = req.query.requisitionId ? parseInt(req.query.requisitionId as string) : undefined;
      const candidateId = req.query.candidateId ? parseInt(req.query.candidateId as string) : undefined;
      const status = req.query.status as string | undefined;
      const applications = await storage.getJobApplications(requisitionId, candidateId, status);
      res.status(200).json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting job applications', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/job-applications/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const application = await storage.getJobApplication(id);
      if (!application) {
        return res.status(404).json({ message: 'Job application not found' });
      }
      res.status(200).json(application);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting job application', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/job-applications', async (req: Request, res: Response) => {
    try {
      const application = await storage.createJobApplication(req.body);
      res.status(201).json(application);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating job application', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/job-applications/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedApplication = await storage.updateJobApplication(id, req.body);
      if (!updatedApplication) {
        return res.status(404).json({ message: 'Job application not found' });
      }
      res.status(200).json(updatedApplication);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating job application', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/interviews', async (req: Request, res: Response) => {
    try {
      const applicationId = req.query.applicationId ? parseInt(req.query.applicationId as string) : undefined;
      const status = req.query.status as string | undefined;
      const interviews = await storage.getInterviews(applicationId, status);
      res.status(200).json(interviews);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting interviews', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/interviews/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const interview = await storage.getInterview(id);
      if (!interview) {
        return res.status(404).json({ message: 'Interview not found' });
      }
      res.status(200).json(interview);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting interview', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/interviews', async (req: Request, res: Response) => {
    try {
      const interview = await storage.createInterview(req.body);
      res.status(201).json(interview);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating interview', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/interviews/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedInterview = await storage.updateInterview(id, req.body);
      if (!updatedInterview) {
        return res.status(404).json({ message: 'Interview not found' });
      }
      res.status(200).json(updatedInterview);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating interview', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/job-offers', async (req: Request, res: Response) => {
    try {
      const applicationId = req.query.applicationId ? parseInt(req.query.applicationId as string) : undefined;
      const status = req.query.status as string | undefined;
      const offers = await storage.getJobOffers(applicationId, status);
      res.status(200).json(offers);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting job offers', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/job-offers/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const offer = await storage.getJobOffer(id);
      if (!offer) {
        return res.status(404).json({ message: 'Job offer not found' });
      }
      res.status(200).json(offer);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting job offer', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/job-offers', async (req: Request, res: Response) => {
    try {
      const offer = await storage.createJobOffer(req.body);
      res.status(201).json(offer);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating job offer', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/job-offers/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedOffer = await storage.updateJobOffer(id, req.body);
      if (!updatedOffer) {
        return res.status(404).json({ message: 'Job offer not found' });
      }
      res.status(200).json(updatedOffer);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating job offer', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Onboarding APIs
  app.get('/api/onboarding-checklists', async (req: Request, res: Response) => {
    try {
      const department = req.query.department as string | undefined;
      const employeeType = req.query.employeeType as string | undefined;
      const checklists = await storage.getOnboardingChecklists(department, employeeType);
      res.status(200).json(checklists);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting onboarding checklists', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/onboarding-checklists/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const checklist = await storage.getOnboardingChecklist(id);
      if (!checklist) {
        return res.status(404).json({ message: 'Onboarding checklist not found' });
      }
      res.status(200).json(checklist);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting onboarding checklist', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/onboarding-checklists', async (req: Request, res: Response) => {
    try {
      const checklist = await storage.createOnboardingChecklist(req.body);
      res.status(201).json(checklist);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating onboarding checklist', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/onboarding-checklists/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedChecklist = await storage.updateOnboardingChecklist(id, req.body);
      if (!updatedChecklist) {
        return res.status(404).json({ message: 'Onboarding checklist not found' });
      }
      res.status(200).json(updatedChecklist);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating onboarding checklist', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/checklist-tasks/:checklistId', async (req: Request, res: Response) => {
    try {
      const checklistId = parseInt(req.params.checklistId);
      const tasks = await storage.getChecklistTasks(checklistId);
      res.status(200).json(tasks);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting checklist tasks', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/checklist-tasks', async (req: Request, res: Response) => {
    try {
      const task = await storage.createChecklistTask(req.body);
      res.status(201).json(task);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating checklist task', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/checklist-tasks/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedTask = await storage.updateChecklistTask(id, req.body);
      if (!updatedTask) {
        return res.status(404).json({ message: 'Checklist task not found' });
      }
      res.status(200).json(updatedTask);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating checklist task', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/employee-onboarding', async (req: Request, res: Response) => {
    try {
      const employeeId = req.query.employeeId ? parseInt(req.query.employeeId as string) : undefined;
      const status = req.query.status as string | undefined;
      const onboardings = await storage.getEmployeeOnboardings(employeeId, status);
      res.status(200).json(onboardings);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting employee onboarding', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/employee-onboarding/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const onboarding = await storage.getEmployeeOnboarding(id);
      if (!onboarding) {
        return res.status(404).json({ message: 'Employee onboarding not found' });
      }
      res.status(200).json(onboarding);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting employee onboarding', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/employee-onboarding', async (req: Request, res: Response) => {
    try {
      const onboarding = await storage.createEmployeeOnboarding(req.body);
      res.status(201).json(onboarding);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating employee onboarding', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/employee-onboarding/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedOnboarding = await storage.updateEmployeeOnboarding(id, req.body);
      if (!updatedOnboarding) {
        return res.status(404).json({ message: 'Employee onboarding not found' });
      }
      res.status(200).json(updatedOnboarding);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating employee onboarding', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/onboarding-tasks', async (req: Request, res: Response) => {
    try {
      const onboardingId = req.query.onboardingId ? parseInt(req.query.onboardingId as string) : undefined;
      const status = req.query.status as string | undefined;
      const tasks = await storage.getOnboardingTasks(onboardingId, status);
      res.status(200).json(tasks);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting onboarding tasks', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get('/api/onboarding-tasks/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const task = await storage.getOnboardingTask(id);
      if (!task) {
        return res.status(404).json({ message: 'Onboarding task not found' });
      }
      res.status(200).json(task);
    } catch (error) {
      res.status(500).json({ message: 'Server error getting onboarding task', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.post('/api/onboarding-tasks', async (req: Request, res: Response) => {
    try {
      const task = await storage.createOnboardingTask(req.body);
      res.status(201).json(task);
    } catch (error) {
      res.status(500).json({ message: 'Server error creating onboarding task', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.put('/api/onboarding-tasks/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedTask = await storage.updateOnboardingTask(id, req.body);
      if (!updatedTask) {
        return res.status(404).json({ message: 'Onboarding task not found' });
      }
      res.status(200).json(updatedTask);
    } catch (error) {
      res.status(500).json({ message: 'Server error updating onboarding task', error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
