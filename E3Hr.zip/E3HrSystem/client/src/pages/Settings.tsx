import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";

export default function Settings() {
  const [activeTab, setActiveTab] = useState("general");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [autoLogout, setAutoLogout] = useState(true);
  const [documentExpiryThreshold, setDocumentExpiryThreshold] = useState(30);
  const [wpsEnabled, setWpsEnabled] = useState(true);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-poppins font-semibold">Settings</CardTitle>
          <CardDescription>Manage your application settings and preferences</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="general" onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5 mb-6">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="notifications">Notifications</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
              <TabsTrigger value="compliance">Compliance</TabsTrigger>
              <TabsTrigger value="api">API Integration</TabsTrigger>
            </TabsList>
            
            {/* General Settings */}
            <TabsContent value="general" className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Company Information</h3>
                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Company Name</Label>
                    <Input id="companyName" placeholder="Your Company Name" defaultValue="E3 HR Solutions" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="companyEmail">Company Email</Label>
                    <Input id="companyEmail" type="email" placeholder="company@example.com" defaultValue="info@e3hr.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="companyPhone">Company Phone</Label>
                    <Input id="companyPhone" placeholder="+974 XXXX XXXX" defaultValue="+974 5555 1234" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="companyAddress">Company Address</Label>
                    <Input id="companyAddress" placeholder="Address" defaultValue="West Bay, Doha, Qatar" />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">System Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">Language</Label>
                      <p className="text-sm text-neutral-500">Set your preferred language</p>
                    </div>
                    <div className="w-[200px]">
                      <select className="w-full p-2 border border-neutral-300 rounded-md">
                        <option value="en">English</option>
                        <option value="ar">Arabic</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">Date Format</Label>
                      <p className="text-sm text-neutral-500">Choose your preferred date format</p>
                    </div>
                    <div className="w-[200px]">
                      <select className="w-full p-2 border border-neutral-300 rounded-md">
                        <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                        <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                        <option value="YYYY/MM/DD">YYYY/MM/DD</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">Time Format</Label>
                      <p className="text-sm text-neutral-500">Choose your preferred time format</p>
                    </div>
                    <div className="w-[200px]">
                      <select className="w-full p-2 border border-neutral-300 rounded-md">
                        <option value="12h">12 Hour (AM/PM)</option>
                        <option value="24h">24 Hour</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline">Reset to Default</Button>
                <Button>Save Changes</Button>
              </div>
            </TabsContent>
            
            {/* Notification Settings */}
            <TabsContent value="notifications" className="space-y-6">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-medium">Notifications</h3>
                    <p className="text-sm text-neutral-500">Manage how you receive notifications</p>
                  </div>
                  <Switch 
                    checked={notificationsEnabled} 
                    onCheckedChange={setNotificationsEnabled}
                  />
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between pl-2">
                    <div>
                      <Label className="font-medium">Email Notifications</Label>
                      <p className="text-sm text-neutral-500">Receive notifications via email</p>
                    </div>
                    <Switch 
                      checked={emailNotifications} 
                      onCheckedChange={setEmailNotifications}
                      disabled={!notificationsEnabled}
                    />
                  </div>
                  <div className="flex items-center justify-between pl-2">
                    <div>
                      <Label className="font-medium">SMS Notifications</Label>
                      <p className="text-sm text-neutral-500">Receive notifications via SMS</p>
                    </div>
                    <Switch 
                      checked={smsNotifications} 
                      onCheckedChange={setSmsNotifications}
                      disabled={!notificationsEnabled}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Notification Events</h3>
                <div className="grid gap-4 grid-cols-1 sm:grid-cols-2">
                  <div className="flex items-start space-x-2 border border-neutral-200 rounded-md p-3">
                    <input type="checkbox" className="mt-1" defaultChecked disabled={!notificationsEnabled} />
                    <div>
                      <Label className="font-medium">Document Expiry</Label>
                      <p className="text-sm text-neutral-500">Notify when documents are about to expire</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2 border border-neutral-200 rounded-md p-3">
                    <input type="checkbox" className="mt-1" defaultChecked disabled={!notificationsEnabled} />
                    <div>
                      <Label className="font-medium">Leave Requests</Label>
                      <p className="text-sm text-neutral-500">Notify for new leave requests and approvals</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2 border border-neutral-200 rounded-md p-3">
                    <input type="checkbox" className="mt-1" defaultChecked disabled={!notificationsEnabled} />
                    <div>
                      <Label className="font-medium">Payroll Processing</Label>
                      <p className="text-sm text-neutral-500">Notify when payroll is processed</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2 border border-neutral-200 rounded-md p-3">
                    <input type="checkbox" className="mt-1" defaultChecked disabled={!notificationsEnabled} />
                    <div>
                      <Label className="font-medium">Event Assignments</Label>
                      <p className="text-sm text-neutral-500">Notify for new event staff assignments</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline">Reset to Default</Button>
                <Button>Save Changes</Button>
              </div>
            </TabsContent>
            
            {/* Security Settings */}
            <TabsContent value="security" className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Account Security</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <Input id="currentPassword" type="password" placeholder="Enter current password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input id="newPassword" type="password" placeholder="Enter new password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <Input id="confirmPassword" type="password" placeholder="Confirm new password" />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Session Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">Auto Logout</Label>
                      <p className="text-sm text-neutral-500">Automatically log out after 30 minutes of inactivity</p>
                    </div>
                    <Switch 
                      checked={autoLogout} 
                      onCheckedChange={setAutoLogout}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">Two-Factor Authentication</Label>
                      <p className="text-sm text-neutral-500">Enable 2FA for additional security</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Setup 2FA
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline">Cancel</Button>
                <Button>Update Password</Button>
              </div>
            </TabsContent>
            
            {/* Compliance Settings */}
            <TabsContent value="compliance" className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Qatar Labor Law Compliance</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">WPS Compliance</Label>
                      <p className="text-sm text-neutral-500">Enable Wage Protection System compliance features</p>
                    </div>
                    <Switch 
                      checked={wpsEnabled} 
                      onCheckedChange={setWpsEnabled}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="wpsCompanyID">WPS Company ID</Label>
                    <Input 
                      id="wpsCompanyID" 
                      placeholder="Enter WPS Company ID" 
                      defaultValue="WPS-12345-QAT"
                      disabled={!wpsEnabled}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">Document Settings</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiryThreshold">Document Expiry Notification Threshold (Days)</Label>
                    <Input 
                      id="expiryThreshold" 
                      type="number" 
                      value={documentExpiryThreshold}
                      onChange={(e) => setDocumentExpiryThreshold(parseInt(e.target.value))}
                      min={1}
                      max={90}
                    />
                    <p className="text-sm text-neutral-500">System will alert you when documents are within this many days of expiring</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="font-medium">Document Archiving</Label>
                      <p className="text-sm text-neutral-500">Automatically archive expired documents after 1 year</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline">Reset to Default</Button>
                <Button>Save Changes</Button>
              </div>
            </TabsContent>
            
            {/* API Integration Settings */}
            <TabsContent value="api" className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">API Connections</h3>
                <div className="space-y-4">
                  <div className="p-4 border border-neutral-200 rounded-md">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium">Qatar Ministry of Labor API</h4>
                        <p className="text-sm text-neutral-500">Connect to MOL services for work permit verification</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-success/10 text-success">Connected</span>
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 border border-neutral-200 rounded-md">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium">Banking APIs</h4>
                        <p className="text-sm text-neutral-500">Connect to banking services for WPS integration</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-warning/10 text-warning">Partial</span>
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                    </div>
                  </div>
                  <div className="p-4 border border-neutral-200 rounded-md">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium">Biometric Device APIs</h4>
                        <p className="text-sm text-neutral-500">Connect to biometric devices for attendance tracking</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-neutral-200 text-neutral-700">Not Connected</span>
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="text-lg font-medium mb-4">API Keys</h3>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="apiKey">Your API Key</Label>
                    <div className="flex">
                      <Input 
                        id="apiKey" 
                        value="••••••••••••••••••••••••••••••"
                        readOnly
                        className="rounded-r-none"
                      />
                      <Button className="rounded-l-none">
                        Copy
                      </Button>
                    </div>
                    <p className="text-sm text-neutral-500">Use this key to access the E3 HR API</p>
                  </div>
                  <div className="flex justify-between">
                    <Button variant="outline" size="sm">
                      <i className="fas fa-sync-alt mr-2"></i> Regenerate Key
                    </Button>
                    <Button variant="outline" size="sm">
                      <i className="fas fa-book mr-2"></i> API Documentation
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button>Save Changes</Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
