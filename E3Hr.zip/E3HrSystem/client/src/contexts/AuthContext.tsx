import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { queryClient } from '@/lib/queryClient';
import { z } from 'zod';

// Development environment mock data
const MOCK_USER = {
  userId: 1,
  username: 'admin',
  role: 'HR Manager',
  firstName: 'Ahmad',
  lastName: 'Al-Mansoori',
  email: 'ahmad@example.com',
  avatar: 'https://ui-avatars.com/api/?name=Ahmad+Al-Mansoori&background=random',
  employeeType: 'Permanent'
};

// User type definition with enhanced role information
interface User {
  userId: number;
  username: string;
  role: string; // This should be one of the UserRole types from permissions.ts
  employeeType?: string;
  contractEndDate?: string;
  department?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  avatar?: string;
  // Additional fields for permission context
  teamId?: string;
  managerId?: number;
  directReports?: number[];
}

// API response types
const loginResponseSchema = z.object({
  success: z.boolean(),
  accessToken: z.string(),
  refreshToken: z.string(),
  user: z.object({
    id: z.number(),
    username: z.string(),
    email: z.string(),
    firstName: z.string(),
    lastName: z.string(),
    role: z.string(),
    department: z.string().optional(),
    lastLogin: z.string().nullable().optional(),
    avatar: z.string().nullable().optional(),
    createdAt: z.string().optional(),
  }),
  message: z.string().optional(),
});

const refreshResponseSchema = z.object({
  success: z.boolean(),
  accessToken: z.string(),
  refreshToken: z.string().optional(),
  user: z.object({
    id: z.number(),
    username: z.string(),
    email: z.string(),
    firstName: z.string(),
    lastName: z.string(),
    role: z.string(),
    department: z.string().optional(),
    avatar: z.string().nullable().optional(),
  }).optional(),
  message: z.string().optional(),
});

// Auth context type definition
interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshToken: () => Promise<string | null>;
  checkTokenExpiration: () => Promise<boolean>;
}

// Create the context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Token related utilities
const isTokenExpired = (token: string): boolean => {
  try {
    const payload = token.split('.')[1];
    const decodedPayload = JSON.parse(atob(payload));
    return decodedPayload.exp * 1000 < Date.now();
  } catch (error) {
    console.error('Error checking token expiration:', error);
    return true; // Assume token is expired if we can't parse it
  }
};

// Auth provider implementation
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Set auth header for all requests
  const setAuthHeader = (newToken: string | null) => {
    if (newToken) {
      // Set for all future fetch requests
      window.localStorage.setItem('accessToken', newToken);
    } else {
      window.localStorage.removeItem('accessToken');
    }
  };

  const checkTokenExpiration = useCallback(async (): Promise<boolean> => {
    const currentToken = window.localStorage.getItem('accessToken');
    
    if (!currentToken) {
      return false;
    }
    
    if (isTokenExpired(currentToken)) {
      try {
        const newToken = await refreshToken();
        return !!newToken;
      } catch (error) {
        return false;
      }
    }
    
    return true;
  }, []);

  // Setup interceptor for API requests
  useEffect(() => {
    // Load token from storage on mount
    const storedToken = window.localStorage.getItem('accessToken');
    if (storedToken) {
      // Try to refresh token
      refreshToken()
        .catch(() => {
          // If refresh fails, clear auth state
          handleLogout(false);
        })
        .finally(() => {
          setIsLoading(false);
        });
    } else {
      setIsLoading(false);
    }
  }, []);

  // Login implementation
  const login = async (username: string, password: string): Promise<void> => {
    try {
      setIsLoading(true);
      
      // Always use the real API for authentication
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
        credentials: 'include',
      });
      
      const rawData = await response.json();
      
      if (!response.ok) {
        throw new Error(rawData.message || 'Authentication failed');
      }
      
      try {
        // Parse and validate response
        const data = loginResponseSchema.parse(rawData);
        
        // Set auth state - map API response to internal User format
        setToken(data.accessToken);
        setUser({
          userId: data.user.id,
          username: data.user.username,
          role: data.user.role,
          firstName: data.user.firstName,
          lastName: data.user.lastName,
          email: data.user.email,
          avatar: data.user.avatar || undefined,
        });
        setAuthHeader(data.accessToken);
        
        // Store refresh token
        window.localStorage.setItem('refreshToken', data.refreshToken);
        
        // Notify user
        toast({
          title: "Login Successful",
          description: "Welcome back!",
          variant: "default",
        });
        
        // Clear and refetch queries with new auth
        queryClient.invalidateQueries();
      } catch (parseError) {
        console.error('Error parsing login response:', parseError);
        throw new Error('Authentication service returned an invalid response');
      }
    } catch (error: any) {
      // Handle login errors
      console.error('Login error:', error);
      
      // Clear any partial auth state
      handleLogout(false);
      
      // Notify user
      toast({
        title: "Login Failed",
        description: error.message || "Authentication failed. Please check your credentials.",
        variant: "destructive",
      });
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Internal logout helper
  const handleLogout = (showToast: boolean = true) => {
    // Clear tokens and state
    setToken(null);
    setUser(null);
    setAuthHeader(null);
    window.localStorage.removeItem('refreshToken');
    
    // Clear query cache to prevent auth issues with cached data
    queryClient.clear();
    
    if (showToast) {
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out.",
        variant: "default",
      });
    }
  };

  // Logout implementation
  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      
      const currentToken = token || window.localStorage.getItem('accessToken');
      const refreshTokenValue = window.localStorage.getItem('refreshToken');
      
      if (currentToken && refreshTokenValue) {
        // Call logout API to invalidate token on server
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${currentToken}`,
          },
          body: JSON.stringify({ refreshToken: refreshTokenValue }),
          credentials: 'include',
        });
      }
      
      handleLogout();
    } catch (error) {
      console.error('Logout error:', error);
      // Still logout locally if API fails
      handleLogout();
    } finally {
      setIsLoading(false);
    }
  };

  const refreshToken = useCallback(async (): Promise<string | null> => {
    try {
      const refreshTokenValue = window.localStorage.getItem('refreshToken');
      
      if (!refreshTokenValue) {
        throw new Error('No refresh token available');
      }
      
      // For development mode, use mock data
      if (import.meta.env.DEV && refreshTokenValue === 'mock-refresh-token') {
        // Mock delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Create a new mock JWT token
        const mockToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInVzZXJuYW1lIjoiYWRtaW4iLCJyb2xlIjoiSFIgTWFuYWdlciIsImlhdCI6MTY0NTAyMTA3NywiZXhwIjoxNjQ1MTA3NDc3fQ.NEW_SIGNATURE';
        
        // Set the token in auth state
        setToken(mockToken);
        setUser(MOCK_USER);
        setAuthHeader(mockToken);
        
        return mockToken;
      }
      
      // For production, use the actual API
      const response = await fetch('/api/auth/refresh-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ refreshToken: refreshTokenValue }),
        credentials: 'include',
      });
      
      const rawData = await response.json();
      
      if (!response.ok) {
        throw new Error(rawData.message || 'Token refresh failed');
      }
      
      try {
        // Parse and validate response
        const data = refreshResponseSchema.parse(rawData);
        
        // Update token state
        setToken(data.accessToken);
        setAuthHeader(data.accessToken);
        
        // Update refresh token if provided
        if (data.refreshToken) {
          window.localStorage.setItem('refreshToken', data.refreshToken);
        }
        
        // Update user data if provided
        if (data.user) {
          setUser({
            userId: data.user.id,
            username: data.user.username,
            role: data.user.role,
            firstName: data.user.firstName,
            lastName: data.user.lastName,
            email: data.user.email,
            department: data.user.department,
            avatar: data.user.avatar || undefined,
          });
        }
        
        return data.accessToken;
      } catch (parseError) {
        console.error('Error parsing refresh token response:', parseError);
        throw new Error('Authentication service returned an invalid response');
      }
    } catch (error) {
      console.error('Token refresh error:', error);
      // Clear auth state on refresh failure
      handleLogout(false);
      throw error;
    }
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        login,
        logout,
        refreshToken,
        checkTokenExpiration,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

// Auth hook
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};