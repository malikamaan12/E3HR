import { db, pool } from "../db";
import { eq, and, isNull, or, sql } from "drizzle-orm";
import { users, authSessions, securityLogs } from "@shared/schema";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";

// Secret key for JWT token signing - should be in environment variable
const JWT_SECRET = process.env.JWT_SECRET || "e3-hr-system-temp-secret";
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || "e3-hr-system-refresh-secret";

// Token expiration times
const ACCESS_TOKEN_EXPIRY = "15m"; // 15 minutes
const REFRESH_TOKEN_EXPIRY = "7d";  // 7 days

export interface TokenPayload {
  userId: number;
  username: string;
  role: string;
  employeeType?: string;
}

interface AuthResponse {
  user: any;
  accessToken: string;
  refreshToken: string;
}

export class AuthService {
  /**
   * Register a new user
   */
  async registerUser(userData: any) {
    try {
      // Hash the password before storing
      const hashedPassword = await bcrypt.hash(userData.password, 12);
      
      // Create user with hashed password
      const newUser = await db.insert(users).values({
        ...userData,
        password: hashedPassword,
        isActive: false, // Requires admin approval
        approvalStatus: "pending",
      }).returning();
      
      // Log the security event
      await this.logSecurityEvent({
        eventType: "user_registration",
        userId: newUser[0].id,
        description: `New user registration: ${userData.username}`,
        ipAddress: userData.ipAddress,
        userAgent: userData.userAgent,
        severity: "info"
      });

      // Return user without password
      const { password, ...userWithoutPassword } = newUser[0];
      return userWithoutPassword;
    } catch (error) {
      console.error("User registration error:", error);
      throw new Error("Failed to register user");
    }
  }

  /**
   * Login a user and generate tokens
   */
  async login(username: string, password: string, ipAddress?: string, userAgent?: string): Promise<AuthResponse> {
    try {
      // Find user by username
      const user = await this.findUserByUsername(username);
      
      if (!user) {
        throw new Error("Invalid credentials");
      }
      
      // Check if account is locked (commented out as lockoutUntil field doesn't exist in current DB schema)
      // if (user.lockoutUntil && new Date(user.lockoutUntil) > new Date()) {
      //   await this.logSecurityEvent({
      //     eventType: "login_failure",
      //     userId: user.id,
      //     description: "Login attempt on locked account",
      //     ipAddress,
      //     userAgent,
      //     severity: "warning" 
      //   });
      //   throw new Error("Account is temporarily locked. Please try again later");
      // }

      // Check if account exists (basic validation)
      // Note: Simplified check since isActive and approvalStatus columns don't exist in current DB schema
      if (!user.username) {
        await this.logSecurityEvent({
          eventType: "login_failure",
          userId: user.id,
          description: "Login attempt on invalid account",
          ipAddress,
          userAgent,
          severity: "warning"
        });
        throw new Error("Account validation failed");
      }
      
      // Compare passwords
      const isPasswordValid = await bcrypt.compare(password, user.password);
      
      if (!isPasswordValid) {
        // Skip failed login attempt tracking since failedLoginAttempts field doesn't exist
        // await this.incrementFailedLoginAttempts(user.id);
        
        await this.logSecurityEvent({
          eventType: "login_failure",
          userId: user.id,
          description: "Invalid password",
          ipAddress,
          userAgent,
          severity: "warning"
        });
        
        throw new Error("Invalid credentials");
      }
      
      // Reset failed login attempts on successful login (if fields exist)
      // Note: Commented out as these fields don't exist in current DB schema
      // if (user.failedLoginAttempts > 0) {
      //   await db.update(users)
      //     .set({ 
      //       failedLoginAttempts: 0,
      //       lockoutUntil: null
      //     })
      //     .where(eq(users.id, user.id));
      // }
      
      // Generate tokens
      const tokenPayload: TokenPayload = {
        userId: user.id,
        username: user.username,
        role: user.role
      };
      
      const accessToken = this.generateAccessToken(tokenPayload);
      const refreshToken = this.generateRefreshToken(tokenPayload);
      
      // Store refresh token in database (only update existing fields)
      await db.update(users)
        .set({ 
          lastLogin: new Date(),
          refreshToken
        })
        .where(eq(users.id, user.id));
      
      // Create auth session
      await db.insert(authSessions).values({
        userId: user.id,
        accessToken,
        refreshToken,
        ipAddress: ipAddress || null,
        userAgent: userAgent || null,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        isActive: true
      });
      
      // Log successful login
      await this.logSecurityEvent({
        eventType: "login_success",
        userId: user.id,
        description: "User logged in successfully",
        ipAddress,
        userAgent,
        severity: "info"
      });
      
      // Remove password from user object
      const { password: _, ...userWithoutPassword } = user;
      
      return {
        user: userWithoutPassword,
        accessToken,
        refreshToken
      };
    } catch (error) {
      console.error("Login error:", error);
      throw error;
    }
  }

  /**
   * Logout user and invalidate tokens
   */
  async logout(userId: number, refreshToken: string, ipAddress?: string, userAgent?: string) {
    try {
      // Invalidate all sessions with this refresh token
      await db.update(authSessions)
        .set({ isActive: false })
        .where(
          and(
            eq(authSessions.userId, userId),
            eq(authSessions.refreshToken, refreshToken)
          )
        );
      
      // Clear refresh token from user
      await db.update(users)
        .set({ refreshToken: null })
        .where(eq(users.id, userId));
      
      // Log the event
      await this.logSecurityEvent({
        eventType: "logout",
        userId,
        description: "User logged out",
        ipAddress,
        userAgent,
        severity: "info"
      });
      
      return { success: true, message: "Logout successful" };
    } catch (error) {
      console.error("Logout error:", error);
      throw new Error("Failed to logout");
    }
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshToken(refreshToken: string, ipAddress?: string, userAgent?: string) {
    try {
      // Verify refresh token
      const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET) as TokenPayload;
      
      // Find user with matching refresh token
      const [user] = await db.select()
        .from(users)
        .where(
          and(
            eq(users.id, decoded.userId),
            eq(users.refreshToken, refreshToken)
          )
        );
      
      if (!user) {
        throw new Error("Invalid refresh token");
      }
      
      // Check if session is active
      const [session] = await db.select()
        .from(authSessions)
        .where(
          and(
            eq(authSessions.userId, user.id),
            eq(authSessions.refreshToken, refreshToken),
            eq(authSessions.isActive, true)
          )
        );
      
      if (!session) {
        throw new Error("Session has been invalidated");
      }
      
      // Generate new tokens
      const tokenPayload: TokenPayload = {
        userId: user.id,
        username: user.username,
        role: user.role
      };
      
      const newAccessToken = this.generateAccessToken(tokenPayload);
      const newRefreshToken = this.generateRefreshToken(tokenPayload);
      
      // Update refresh token in database
      await db.update(users)
        .set({ refreshToken: newRefreshToken })
        .where(eq(users.id, user.id));
      
      // Update session
      await db.update(authSessions)
        .set({
          accessToken: newAccessToken,
          refreshToken: newRefreshToken,
          issuedAt: new Date(),
          lastUsed: new Date(),
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
        })
        .where(eq(authSessions.id, session.id));
      
      // Log the event
      await this.logSecurityEvent({
        // Keep this within the current database enum until a schema migration
        // adds a dedicated token_refresh event type.
        eventType: "api_access",
        userId: user.id,
        description: "Access token refreshed",
        ipAddress,
        userAgent,
        severity: "info"
      });
      
      // Remove password from user object
      const { password, ...userWithoutPassword } = user;
      
      return {
        user: userWithoutPassword,
        accessToken: newAccessToken,
        refreshToken: newRefreshToken
      };
    } catch (error) {
      console.error("Token refresh error:", error);
      throw new Error("Failed to refresh token");
    }
  }

  /**
   * Request password reset for a user
   */
  async requestPasswordReset(email: string, ipAddress?: string, userAgent?: string) {
    try {
      // Find user by email
      const [user] = await db.select()
        .from(users)
        .where(eq(users.email, email));
      
      if (!user) {
        // Don't reveal that the email doesn't exist
        return { 
          success: true, 
          message: "If your email is registered, you will receive a password reset link"
        };
      }
      
      // Generate a unique reset token
      const resetToken = uuidv4();
      
      // Store hashed token in database with expiry (2 hours)
      const hashedToken = await bcrypt.hash(resetToken, 12);
      await db.update(users)
        .set({
          passwordResetToken: hashedToken,
          passwordResetExpires: new Date(Date.now() + 2 * 60 * 60 * 1000) // 2 hours
        })
        .where(eq(users.id, user.id));
      
      // Log the event
      await this.logSecurityEvent({
        eventType: "password_reset_request",
        userId: user.id,
        description: "Password reset requested",
        ipAddress,
        userAgent,
        severity: "info"
      });
      
      // In a real app, send an email with the reset link including the token
      // For now, just return the token (this is not secure for production)
      return {
        success: true,
        message: "If your email is registered, you will receive a password reset link",
        resetToken // In production, remove this and send via email
      };
    } catch (error) {
      console.error("Password reset request error:", error);
      throw new Error("Failed to process password reset request");
    }
  }

  /**
   * Reset password using reset token
   */
  async resetPassword(
    resetToken: string, 
    newPassword: string, 
    ipAddress?: string, 
    userAgent?: string
  ) {
    try {
      // Find user with non-expired reset token
      const [user] = await db.select()
        .from(users)
        .where(
          and(
            isNull(users.passwordResetToken).not(),
            isNull(users.passwordResetExpires).not(),
            users.passwordResetExpires.gt(new Date())
          )
        );
      
      if (!user) {
        throw new Error("Invalid or expired reset token");
      }
      
      // Verify the token - compare plain token with hashed one in DB
      const isValidToken = await bcrypt.compare(resetToken, user.passwordResetToken);
      
      if (!isValidToken) {
        throw new Error("Invalid reset token");
      }
      
      // Hash the new password
      const hashedPassword = await bcrypt.hash(newPassword, 12);
      
      // Update user password and clear reset token fields
      await db.update(users)
        .set({
          password: hashedPassword,
          passwordResetToken: null,
          passwordResetExpires: null,
          failedLoginAttempts: 0,
          lockoutUntil: null
        })
        .where(eq(users.id, user.id));
      
      // Invalidate all active sessions for this user
      await db.update(authSessions)
        .set({ isActive: false })
        .where(eq(authSessions.userId, user.id));
      
      // Log the event
      await this.logSecurityEvent({
        eventType: "password_change",
        userId: user.id,
        description: "Password reset via token",
        ipAddress,
        userAgent,
        severity: "info"
      });
      
      return { success: true, message: "Password has been reset successfully" };
    } catch (error) {
      console.error("Password reset error:", error);
      throw error;
    }
  }

  /**
   * Change password (when user is logged in)
   */
  async changePassword(
    userId: number, 
    currentPassword: string, 
    newPassword: string,
    ipAddress?: string,
    userAgent?: string
  ) {
    try {
      // Find user
      const [user] = await db.select()
        .from(users)
        .where(eq(users.id, userId));
      
      if (!user) {
        throw new Error("User not found");
      }
      
      // Verify current password
      const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
      
      if (!isPasswordValid) {
        // Log failed attempt
        await this.logSecurityEvent({
          eventType: "password_change_failure",
          userId: user.id,
          description: "Failed password change attempt - incorrect current password",
          ipAddress,
          userAgent,
          severity: "warning"
        });
        
        throw new Error("Current password is incorrect");
      }
      
      // Hash the new password
      const hashedPassword = await bcrypt.hash(newPassword, 12);
      
      // Update user password
      await db.update(users)
        .set({ password: hashedPassword })
        .where(eq(users.id, userId));
      
      // Log the event
      await this.logSecurityEvent({
        eventType: "password_change",
        userId,
        description: "Password changed by user",
        ipAddress,
        userAgent,
        severity: "info"
      });
      
      return { success: true, message: "Password has been changed successfully" };
    } catch (error) {
      console.error("Password change error:", error);
      throw error;
    }
  }

  /**
   * Admin approval of a user account
   */
  async approveUserAccount(userId: number, approvedByUserId: number) {
    try {
      // Find user to approve
      const [user] = await db.select()
        .from(users)
        .where(eq(users.id, userId));
      
      if (!user) {
        throw new Error("User not found");
      }
      
      // Check if already approved
      if (user.approvalStatus === "approved") {
        return { success: true, message: "User is already approved" };
      }
      
      // Update user status
      await db.update(users)
        .set({
          approvalStatus: "approved",
          isActive: true,
          approvedBy: approvedByUserId,
          approvedAt: new Date()
        })
        .where(eq(users.id, userId));
      
      // Log the event
      await this.logSecurityEvent({
        eventType: "user_approval",
        userId: approvedByUserId,
        description: `User account approved: ${user.username}`,
        resourceId: userId.toString(),
        severity: "info"
      });
      
      return { success: true, message: "User account has been approved" };
    } catch (error) {
      console.error("User approval error:", error);
      throw new Error("Failed to approve user account");
    }
  }

  /**
   * Update user role
   */
  async updateUserRole(userId: number, newRole: string, updatedByUserId: number) {
    try {
      // Find user
      const [user] = await db.select()
        .from(users)
        .where(eq(users.id, userId));
      
      if (!user) {
        throw new Error("User not found");
      }
      
      // Update role
      await db.update(users)
        .set({ role: newRole })
        .where(eq(users.id, userId));
      
      // Log the event
      await this.logSecurityEvent({
        eventType: "role_assignment",
        userId: updatedByUserId,
        description: `User role updated for ${user.username} to ${newRole}`,
        resourceId: userId.toString(),
        severity: "info"
      });
      
      return { success: true, message: "User role has been updated" };
    } catch (error) {
      console.error("Role update error:", error);
      throw new Error("Failed to update user role");
    }
  }

  /**
   * Verify access token
   */
  verifyAccessToken(token: string): TokenPayload {
    try {
      return jwt.verify(token, JWT_SECRET) as TokenPayload;
    } catch (error) {
      throw new Error("Invalid token");
    }
  }

  /**
   * Get user by ID
   */
  async getUserById(userId: number) {
    try {
      const [user] = await db.select()
        .from(users)
        .where(eq(users.id, userId));
      
      if (!user) {
        return null;
      }
      
      // Remove sensitive data
      const { password, refreshToken, passwordResetToken, ...safeUser } = user;
      return safeUser;
    } catch (error) {
      console.error("Get user error:", error);
      throw new Error("Failed to get user");
    }
  }

  /**
   * Find user by username
   */
  async findUserByUsername(username: string) {
    try {
      // Use direct pool connection to bypass drizzle schema issues
      const result = await pool.query(
        'SELECT id, username, password, email, first_name, last_name, role, department, last_login, avatar, created_at FROM users WHERE username = $1',
        [username]
      );
      
      const user = result.rows[0];
      return user ? {
        id: user.id,
        username: user.username,
        password: user.password,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        department: user.department,
        lastLogin: user.last_login,
        avatar: user.avatar,
        createdAt: user.created_at
      } : null;
    } catch (error) {
      console.error("Find user error:", error);
      throw new Error("Failed to find user");
    }
  }

  /**
   * Find user by email
   */
  async findUserByEmail(email: string) {
    try {
      const [user] = await db.select({
        id: users.id,
        username: users.username,
        password: users.password,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        role: users.role,
        department: users.department,
        lastLogin: users.lastLogin,
        avatar: users.avatar,
        createdAt: users.createdAt
      })
        .from(users)
        .where(eq(users.email, email));
      
      return user || null;
    } catch (error) {
      console.error("Find user error:", error);
      throw new Error("Failed to find user");
    }
  }

  /**
   * Get pending users for approval
   */
  async getPendingUsers() {
    try {
      const pendingUsers = await db.select({
        id: users.id,
        username: users.username,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        role: users.role,
        department: users.department,
        qidNumber: users.qidNumber,
        createdAt: users.createdAt
      })
      .from(users)
      .where(eq(users.approvalStatus, "pending"));
      
      return pendingUsers;
    } catch (error) {
      console.error("Get pending users error:", error);
      throw new Error("Failed to get pending users");
    }
  }

  /**
   * Get user's active sessions
   */
  async getUserSessions(userId: number) {
    try {
      const sessions = await db.select()
        .from(authSessions)
        .where(
          and(
            eq(authSessions.userId, userId),
            eq(authSessions.isActive, true)
          )
        );
      
      return sessions;
    } catch (error) {
      console.error("Get user sessions error:", error);
      throw new Error("Failed to get user sessions");
    }
  }

  /**
   * Revoke a specific session
   */
  async revokeSession(sessionId: number, revokingUserId: number) {
    try {
      // Get session first
      const [session] = await db.select()
        .from(authSessions)
        .where(eq(authSessions.id, sessionId));
      
      if (!session) {
        throw new Error("Session not found");
      }
      
      // Update session
      await db.update(authSessions)
        .set({ isActive: false })
        .where(eq(authSessions.id, sessionId));
      
      // Log the event
      await this.logSecurityEvent({
        eventType: "session_revoked",
        userId: revokingUserId,
        description: `Session revoked for user ID ${session.userId}`,
        resourceId: sessionId.toString(),
        severity: "info"
      });
      
      return { success: true, message: "Session has been revoked" };
    } catch (error) {
      console.error("Revoke session error:", error);
      throw new Error("Failed to revoke session");
    }
  }

  /**
   * Handle failed login attempts and account lockout
   * Note: Disabled since failedLoginAttempts and lockoutUntil fields don't exist in current DB schema
   */
  private async incrementFailedLoginAttempts(userId: number) {
    // Commented out as these fields don't exist in current database schema
    // try {
    //   // Get current failed attempts
    //   const [user] = await db.select()
    //     .from(users)
    //     .where(eq(users.id, userId));
    //   
    //   if (!user) return;
    //   
    //   const newFailedAttempts = (user.failedLoginAttempts || 0) + 1;
    //   const updateData: Record<string, any> = {
    //     failedLoginAttempts: newFailedAttempts
    //   };
    //   
    //   // Lock account after 5 failed attempts
    //   if (newFailedAttempts >= 5) {
    //     // Lock for 30 minutes
    //     updateData.lockoutUntil = new Date(Date.now() + 30 * 60 * 1000);
    //     
    //     // Log account lockout
    //     await this.logSecurityEvent({
    //       eventType: "account_lockout",
    //       userId,
    //       description: "Account locked due to multiple failed login attempts",
    //       severity: "warning"
    //     });
    //   }
    //   
    //   // Update user record
    //   await db.update(users)
    //     .set(updateData)
    //     .where(eq(users.id, userId));
    // } catch (error) {
    //   console.error("Error incrementing failed login attempts:", error);
    // }
  }

  /**
   * Generate access token
   */
  private generateAccessToken(payload: TokenPayload): string {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_TOKEN_EXPIRY });
  }

  /**
   * Generate refresh token
   */
  private generateRefreshToken(payload: TokenPayload): string {
    return jwt.sign(payload, JWT_REFRESH_SECRET, { expiresIn: REFRESH_TOKEN_EXPIRY });
  }

  /**
   * Log security event
   */
  private async logSecurityEvent({
    eventType,
    userId,
    description,
    ipAddress,
    userAgent,
    resourceType,
    resourceId,
    metadata,
    severity = "info"
  }: {
    eventType: string;
    userId?: number;
    description: string;
    ipAddress?: string;
    userAgent?: string;
    resourceType?: string;
    resourceId?: string;
    metadata?: any;
    severity?: string;
  }) {
    try {
      await db.insert(securityLogs).values({
        eventType: eventType as any,
        userId,
        description,
        ipAddress: ipAddress || null,
        userAgent: userAgent || null,
        resourceType: resourceType || null,
        resourceId: resourceId || null,
        metadata: metadata ? metadata : null,
        severity
      });
    } catch (error) {
      console.error("Error logging security event:", error);
    }
  }
}

export const authService = new AuthService();