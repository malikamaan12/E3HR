import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";

interface DocumentData {
  documentType: string;
  expiringSoon: number;
  expired: number;
  status: string;
}

export default function ComplianceStatus() {
  const { data, isLoading } = useQuery({
    queryKey: ['/api/documents/expiring'],
    staleTime: 1000 * 60 * 5,
  });

  const fallbackData: DocumentData[] = [
    { documentType: "Work Permits", expiringSoon: 8, expired: 2, status: "warning" },
    { documentType: "ID Cards", expiringSoon: 3, expired: 0, status: "success" },
    { documentType: "Visa Documents", expiringSoon: 12, expired: 4, status: "error" },
  ];

  const documents = (data || fallbackData) as any[];

  return (
    <div className="glass-bento-card p-5 sm:p-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4 sm:mb-6 gap-2">
        <h3 className="text-lg sm:text-xl font-bold text-e3-aurora truncate">Compliance Health</h3>
        <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full border-4 border-teal-500 border-t-transparent animate-spin shrink-0" style={{ animationDuration: '3s' }} />
      </div>
      
      <div className="space-y-3 sm:space-y-4 flex-1 min-w-0">
        {isLoading ? (
          <div className="flex items-center justify-center h-full text-slate-400">Loading...</div>
        ) : (
          documents.map((doc: any, index: number) => (
            <div key={index} className="group min-w-0">
              <div className="flex justify-between text-xs sm:text-sm mb-1.5 gap-2 min-w-0">
                <span className="font-medium dark:text-slate-300 truncate min-w-0">{doc.documentType}</span>
                <span className={cn(
                  "font-bold whitespace-nowrap shrink-0",
                  doc.status === 'error' ? 'text-rose-500' : 
                  doc.status === 'warning' ? 'text-amber-500' : 'text-teal-500'
                )}>
                  {doc.expired > 0 ? `${doc.expired} expired` : `${doc.expiringSoon} soon`}
                </span>
              </div>
              <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className={cn(
                    "h-full transition-all duration-1000 group-hover:opacity-80",
                    doc.status === 'error' ? 'bg-rose-500' : 
                    doc.status === 'warning' ? 'bg-amber-500' : 'bg-teal-500'
                  )}
                  style={{ width: `${Math.min(100, ((doc.expired + doc.expiringSoon) / 20) * 100)}%` }}
                />
              </div>
            </div>
          ))
        )}
      </div>
      
      <button className="mt-4 sm:mt-6 w-full py-2 sm:py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm font-medium hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors dark:text-slate-300">
        Full Audit Report
      </button>
    </div>
  );
}
