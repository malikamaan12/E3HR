import { Router, Request, Response, NextFunction } from 'express';
import { db } from '../db';
import { eq, and, gte, lte, isNotNull, desc } from 'drizzle-orm';
import { storage } from '../storage';
import { requireAuth } from '../middleware/auth';
import { employees, attendance, documents, leaves, shiftSchedules, users } from '@shared/schema';
import multer from 'multer';
import path from 'path';
import { format } from 'date-fns';
import jwt from 'jsonwebtoken';

const router = Router();

// Middleware for JWT verification
export const verifyJWT = (req: Request, res: Response, next: NextFunction) => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        success: false,
        message: 'Authentication required. No token provided.'
      });
    }
    
    const token = authHeader.split(' ')[1];
    
    // Secret should be stored in environment variables in production
    const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
    
    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET) as { id: number, username: string, role: string };
    
    // Attach user info to request
    (req as any).user = decoded;
    
    // Check if the user still exists and has proper permissions
    db.select()
      .from(users)
      .where(eq(users.id, decoded.id))
      .limit(1)
      .then(([user]) => {
        if (!user) {
          return res.status(401).json({ 
            success: false, 
            message: 'User associated with this token no longer exists'
          });
        }
        
        // User exists, continue with request
        next();
      })
      .catch(error => {
        console.error('Error verifying user existence:', error);
        return res.status(500).json({ 
          success: false, 
          message: 'Server error verifying user',
          error: error instanceof Error ? error.message : 'Unknown error'
        });
      });
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return res.status(401).json({ 
        success: false, 
        message: 'Invalid token. Please login again.' 
      });
    }
    
    if (error instanceof jwt.TokenExpiredError) {
      return res.status(401).json({ 
        success: false, 
        message: 'Session expired. Please login again.' 
      });
    }
    
    res.status(500).json({ 
      success: false, 
      message: 'Server error verifying authentication',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
};

// Rate limiting middleware
export const rateLimiter = (limit: number, timeWindow: number) => {
  const requests: Record<string, { count: number, resetTime: number }> = {};
  
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.connection.remoteAddress || 'unknown';
    const now = Date.now();
    
    if (!requests[ip]) {
      requests[ip] = {
        count: 1,
        resetTime: now + timeWindow
      };
      return next();
    }
    
    if (now > requests[ip].resetTime) {
      requests[ip] = {
        count: 1,
        resetTime: now + timeWindow
      };
      return next();
    }
    
    if (requests[ip].count >= limit) {
      return res.status(429).json({ message: 'Too many requests, please try again later' });
    }
    
    requests[ip].count++;
    next();
  };
};

// Apply rate limiting to all mobile endpoints: 60 requests per minute
router.use(rateLimiter(60, 60 * 1000));

// Authentication endpoint - generate JWT token
router.post('/auth/login', async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;
    
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }
    
    // Query directly from database instead of using storage abstraction
    const [user] = await db.select().from(users).where(eq(users.username, username));
    
    if (!user || user.password !== password) { // In production, should use bcrypt.compare
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Secret should be stored in environment variables in production
    const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
    const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';
    
    // Generate JWT token
    const token = jwt.sign(
      { 
        id: user.id, 
        username: user.username, 
        role: user.role 
      }, 
      JWT_SECRET, 
      { expiresIn: JWT_EXPIRES_IN }
    );
    
    res.status(200).json({ 
      token,
      user: {
        id: user.id,
        username: user.username,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error during login', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Mobile API endpoint to get employee profile
router.get('/employee-profile', verifyJWT, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user.id;
    
    if (!userId) {
      return res.status(400).json({ message: 'User ID is required' });
    }
    
    // Get employee data
    const employeeData = await db.select({
      id: employees.id,
      firstName: employees.firstName,
      lastName: employees.lastName,
      employeeId: employees.employeeId,
      department: employees.department,
      jobTitle: employees.jobTitle,
      profileImage: employees.profileImage
    })
    .from(employees)
    .where(eq(employees.userId, userId))
    .limit(1);
    
    if (!employeeData || employeeData.length === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    
    // Return simplified profile data for mobile
    res.status(200).json({
      id: employeeData[0].id,
      employeeId: employeeData[0].employeeId,
      name: `${employeeData[0].firstName} ${employeeData[0].lastName}`,
      department: employeeData[0].department,
      position: employeeData[0].jobTitle,
      profileImage: employeeData[0].profileImage
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error retrieving employee profile', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Mobile API endpoint to get shift schedule for the next 7 days
router.get('/shift-schedule/:employeeId', verifyJWT, async (req: Request, res: Response) => {
  try {
    const employeeId = parseInt(req.params.employeeId);
    const userId = (req as any).user.id;
    
    // Additional security check to ensure users can only access their own data
    const employee = await db.select()
      .from(employees)
      .where(eq(employees.id, employeeId))
      .limit(1);
    
    if (!employee || employee.length === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    
    if (employee[0].userId !== userId && (req as any).user.role !== 'admin' && (req as any).user.role !== 'hr') {
      return res.status(403).json({ message: 'Unauthorized to access this employee data' });
    }
    
    // Get current date and calculate date 7 days from now
    const today = new Date();
    const nextWeek = new Date();
    nextWeek.setDate(today.getDate() + 7);
    
    const todayStr = format(today, 'yyyy-MM-dd');
    const nextWeekStr = format(nextWeek, 'yyyy-MM-dd');
    
    // Query shift schedules for the next 7 days
    const shifts = await db.select({
      id: shiftSchedules.id,
      date: shiftSchedules.date,
      shiftName: shiftSchedules.shiftName,
      startTime: shiftSchedules.startTime,
      endTime: shiftSchedules.endTime,
      location: shiftSchedules.location,
      notes: shiftSchedules.notes
    })
    .from(shiftSchedules)
    .where(
      eq(shiftSchedules.employeeId, employeeId)
      // Add date range filter here once we fix schema issues
    );
    
    // Format for mobile consumption
    const formattedShifts = shifts.map(shift => ({
      id: shift.id,
      date: shift.date,
      shift: shift.shiftName,
      time: `${new Date(shift.startTime).toLocaleTimeString()} - ${new Date(shift.endTime).toLocaleTimeString()}`,
      location: shift.location,
      notes: shift.notes
    }));
    
    res.status(200).json({
      employeeId,
      shifts: formattedShifts,
      period: {
        from: todayStr,
        to: nextWeekStr
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error retrieving shift schedule', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Configure multer for document uploads
const uploadStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/documents');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    const ext = path.extname(file.originalname);
    cb(null, `document-${uniqueSuffix}${ext}`);
  }
});

const upload = multer({
  storage: uploadStorage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow only certain file types
    const allowedTypes = ['.pdf', '.jpg', '.jpeg', '.png', '.doc', '.docx'];
    const ext = path.extname(file.originalname).toLowerCase();
    
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, JPG, PNG, DOC, and DOCX files are allowed.') as any);
    }
  }
});

// Mobile API endpoint for document submission
router.post('/submit-document', verifyJWT, upload.single('document'), async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No document file uploaded' });
    }
    
    const { employeeId, documentType, documentNumber, issueDate, expiryDate, issueAuthority, notes } = req.body;
    
    if (!employeeId || !documentType) {
      return res.status(400).json({ message: 'Employee ID and document type are required' });
    }
    
    // Parse employee ID to number
    const empId = parseInt(employeeId);
    
    // Insert document data into database
    const documentData = {
      employeeId: empId,
      documentType,
      documentNumber: documentNumber || null,
      issueDate: issueDate || null,
      expiryDate: expiryDate || null,
      issueAuthority: issueAuthority || null,
      notes: notes || null,
      status: 'pending',
      filePath: req.file.path,
      uploadedBy: (req as any).user.id,
      uploadedAt: new Date()
    };
    
    // Insert document into database
    const [newDocument] = await db.insert(documents)
      .values(documentData)
      .returning();
    
    // Log activity
    // TODO: Call activity logging service
    
    res.status(201).json({
      success: true,
      documentId: newDocument.id,
      message: 'Document submitted successfully',
      status: 'pending'
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error submitting document', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Mobile API endpoint for leave request submission
router.post('/leave-request', verifyJWT, async (req: Request, res: Response) => {
  try {
    const { employeeId, leaveType, startDate, endDate, reason, contactDetails } = req.body;
    
    if (!employeeId || !leaveType || !startDate || !endDate) {
      return res.status(400).json({ message: 'Employee ID, leave type, start date, and end date are required' });
    }
    
    // Parse employee ID to number
    const empId = parseInt(employeeId);
    
    // Validate date format and range
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return res.status(400).json({ message: 'Invalid date format' });
    }
    
    if (start > end) {
      return res.status(400).json({ message: 'Start date cannot be after end date' });
    }
    
    // Create leave request
    const leaveData = {
      employeeId: empId,
      leaveType,
      startDate: startDate,
      endDate: endDate,
      reason: reason || null,
      contactDetails: contactDetails || null,
      status: 'pending',
      appliedAt: new Date(),
      appliedBy: (req as any).user.id,
    };
    
    // Insert leave request into database
    const [newLeave] = await db.insert(leaves)
      .values(leaveData)
      .returning();
    
    // TODO: Send push notification to manager about new leave request
    
    res.status(201).json({
      success: true,
      leaveId: newLeave.id,
      message: 'Leave request submitted successfully',
      status: 'pending'
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error submitting leave request', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Mobile API endpoint to get available shifts
router.get('/available-shifts/:employeeId', verifyJWT, async (req: Request, res: Response) => {
  try {
    const employeeId = parseInt(req.params.employeeId);
    const userId = (req as any).user.id;
    
    // Additional security check to ensure users can only access their own data
    const employee = await db.select()
      .from(employees)
      .where(eq(employees.id, employeeId))
      .limit(1);
    
    if (!employee || employee.length === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    
    if (employee[0].userId !== userId && (req as any).user.role !== 'admin' && (req as any).user.role !== 'hr') {
      return res.status(403).json({ message: 'Unauthorized to access this employee data' });
    }
    
    // Get available shifts
    // This would normally involve a more complex query considering employee skills, 
    // qualifications, and availability patterns
    // For this implementation, we'll return a simplified version
    
    // Get current date
    const today = new Date();
    const todayStr = format(today, 'yyyy-MM-dd');
    
    // Query available shifts
    // This is a placeholder query - in reality would need to join with employee skills 
    // and qualifications tables and filter by employee department etc.
    const shifts = await db.select({
      id: shiftSchedules.id,
      date: shiftSchedules.date,
      shiftName: shiftSchedules.shiftName,
      startTime: shiftSchedules.startTime,
      endTime: shiftSchedules.endTime,
      location: shiftSchedules.location,
      notes: shiftSchedules.notes
    })
    .from(shiftSchedules)
    .where(
      eq(shiftSchedules.employeeId, 0) // Shifts not assigned to anyone
      // Add date filter for future dates once we fix schema issues
    )
    .limit(10);
    
    // Format for mobile consumption
    const availableShifts = shifts.map(shift => ({
      id: shift.id,
      date: shift.date,
      shift: shift.shiftName,
      time: `${new Date(shift.startTime).toLocaleTimeString()} - ${new Date(shift.endTime).toLocaleTimeString()}`,
      location: shift.location,
      notes: shift.notes
    }));
    
    res.status(200).json({
      employeeId,
      availableShifts,
      count: availableShifts.length
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error retrieving available shifts', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Mobile API endpoint to claim a shift
router.post('/claim-shift/:shiftId', verifyJWT, async (req: Request, res: Response) => {
  try {
    const shiftId = parseInt(req.params.shiftId);
    const { employeeId } = req.body;
    
    if (!employeeId) {
      return res.status(400).json({ message: 'Employee ID is required' });
    }
    
    const empId = parseInt(employeeId);
    const userId = (req as any).user.id;
    
    // Additional security check to ensure users can only access their own data
    const employee = await db.select()
      .from(employees)
      .where(eq(employees.id, empId))
      .limit(1);
    
    if (!employee || employee.length === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }
    
    if (employee[0].userId !== userId && (req as any).user.role !== 'admin' && (req as any).user.role !== 'hr') {
      return res.status(403).json({ message: 'Unauthorized to claim shift for this employee' });
    }
    
    // Check if shift exists and is available
    const shift = await db.select()
      .from(shiftSchedules)
      .where(eq(shiftSchedules.id, shiftId))
      .limit(1);
    
    if (!shift || shift.length === 0) {
      return res.status(404).json({ message: 'Shift not found' });
    }
    
    if (shift[0].employeeId !== 0) {
      return res.status(400).json({ message: 'Shift is already assigned to an employee' });
    }
    
    // Update shift to assign to employee
    const [updatedShift] = await db.update(shiftSchedules)
      .set({
        employeeId: empId,
        updatedAt: new Date()
      })
      .where(eq(shiftSchedules.id, shiftId))
      .returning();
    
    // TODO: Send push notification to employee confirming shift claim
    
    res.status(200).json({
      success: true,
      shiftId,
      employeeId: empId,
      message: 'Shift claimed successfully',
      shift: {
        date: updatedShift.date,
        shift: updatedShift.shiftName,
        time: `${new Date(updatedShift.startTime).toLocaleTimeString()} - ${new Date(updatedShift.endTime).toLocaleTimeString()}`,
        location: updatedShift.location
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error claiming shift', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Firebase Cloud Messaging (FCM) for push notifications
// This would normally integrate with a separate notification service
const sendPushNotification = async (token: string, payload: any) => {
  try {
    // This is a placeholder for actual FCM integration
    console.log(`Sending push notification to token: ${token}`);
    console.log('Payload:', payload);
    
    // In a real implementation, this would use the firebase-admin SDK
    return {
      success: true,
      messageId: `mock-message-id-${Date.now()}`
    };
  } catch (error) {
    console.error('Error sending push notification:', error);
    throw error;
  }
};

// Mobile API endpoint to register a device for push notifications
router.post('/register-device', verifyJWT, async (req: Request, res: Response) => {
  try {
    const { fcmToken, deviceId, platform } = req.body;
    const userId = (req as any).user.id;
    
    if (!fcmToken || !deviceId || !platform) {
      return res.status(400).json({ message: 'FCM token, device ID, and platform are required' });
    }
    
    // In a real implementation, this would store the token in a database table
    // For this prototype, we'll just return success
    
    res.status(200).json({
      success: true,
      message: 'Device registered for push notifications',
      userId
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error registering device', error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Mobile API endpoint for attendance clock-in
router.post('/attendance/clock-in', verifyJWT, async (req: Request, res: Response) => {
  try {
    const { employeeId, latitude, longitude, notes } = req.body;
    const userId = (req as any).user.id;
    
    if (!employeeId) {
      return res.status(400).json({ 
        success: false,
        message: 'Employee ID is required' 
      });
    }
    
    const empId = parseInt(employeeId);
    
    // Verify employee belongs to authenticated user
    const employee = await db.select()
      .from(employees)
      .where(eq(employees.id, empId))
      .limit(1);
      
    if (!employee || employee.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    if (employee[0].userId !== userId && (req as any).user.role !== 'admin' && (req as any).user.role !== 'hr') {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to clock in for this employee'
      });
    }
    
    // Check if already clocked in for today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const existingAttendance = await db.select()
      .from(attendance)
      .where(
        and(
          eq(attendance.employeeId, empId),
          gte(attendance.date, today.toISOString())
        )
      )
      .limit(1);
      
    if (existingAttendance && existingAttendance.length > 0 && existingAttendance[0].checkIn) {
      return res.status(400).json({
        success: false,
        message: 'Already clocked in for today',
        attendance: {
          id: existingAttendance[0].id,
          date: existingAttendance[0].date,
          checkIn: existingAttendance[0].checkIn
        }
      });
    }
    
    // Create or update attendance record
    const now = new Date();
    const attendanceData = {
      employeeId: empId,
      date: today.toISOString().split('T')[0],
      checkIn: now.toISOString(),
      checkInMethod: 'mobile_app',
      status: 'present',
      location: latitude && longitude ? `${latitude},${longitude}` : null,
      notes: notes || null,
      createdAt: now,
      updatedAt: now
    };
    
    let result;
    
    if (existingAttendance && existingAttendance.length > 0) {
      // Update existing record
      [result] = await db.update(attendance)
        .set(attendanceData)
        .where(eq(attendance.id, existingAttendance[0].id))
        .returning();
    } else {
      // Create new record
      [result] = await db.insert(attendance)
        .values(attendanceData)
        .returning();
    }
    
    res.status(200).json({
      success: true,
      message: 'Successfully clocked in',
      attendance: {
        id: result.id,
        date: result.date,
        checkIn: result.checkIn,
        location: result.location
      }
    });
  } catch (error) {
    console.error('Clock-in error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during clock-in',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Mobile API endpoint for attendance clock-out
router.post('/attendance/clock-out', verifyJWT, async (req: Request, res: Response) => {
  try {
    const { employeeId, latitude, longitude, notes } = req.body;
    const userId = (req as any).user.id;
    
    if (!employeeId) {
      return res.status(400).json({
        success: false,
        message: 'Employee ID is required'
      });
    }
    
    const empId = parseInt(employeeId);
    
    // Verify employee belongs to authenticated user
    const employee = await db.select()
      .from(employees)
      .where(eq(employees.id, empId))
      .limit(1);
      
    if (!employee || employee.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    if (employee[0].userId !== userId && (req as any).user.role !== 'admin' && (req as any).user.role !== 'hr') {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to clock out for this employee'
      });
    }
    
    // Check for an active attendance record
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const existingAttendance = await db.select()
      .from(attendance)
      .where(
        and(
          eq(attendance.employeeId, empId),
          gte(attendance.date, today.toISOString()),
          isNotNull(attendance.checkIn)
        )
      )
      .limit(1);
      
    if (!existingAttendance || existingAttendance.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No active clock-in found for today. Please clock in first.'
      });
    }
    
    if (existingAttendance[0].checkOut) {
      return res.status(400).json({
        success: false,
        message: 'Already clocked out for today',
        attendance: {
          id: existingAttendance[0].id,
          date: existingAttendance[0].date,
          checkIn: existingAttendance[0].checkIn,
          checkOut: existingAttendance[0].checkOut
        }
      });
    }
    
    // Update attendance record with clock-out
    const now = new Date();
    const checkInTime = new Date(existingAttendance[0].checkIn);
    
    // Calculate hours worked
    const hoursWorked = (now.getTime() - checkInTime.getTime()) / 1000 / 60 / 60;
    
    const [result] = await db.update(attendance)
      .set({
        checkOut: now.toISOString(),
        location: latitude && longitude ? `${latitude},${longitude}` : null,
        notes: notes || existingAttendance[0].notes, // Append or keep existing notes
        hoursWorked: parseFloat(hoursWorked.toFixed(2)),
        updatedAt: now
      })
      .where(eq(attendance.id, existingAttendance[0].id))
      .returning();
    
    res.status(200).json({
      success: true,
      message: 'Successfully clocked out',
      attendance: {
        id: result.id,
        date: result.date,
        checkIn: result.checkIn,
        checkOut: result.checkOut,
        hoursWorked: result.hoursWorked
      }
    });
  } catch (error) {
    console.error('Clock-out error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during clock-out',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// Mobile API endpoint to get attendance history
router.get('/attendance/history/:employeeId', verifyJWT, async (req: Request, res: Response) => {
  try {
    const employeeId = parseInt(req.params.employeeId);
    const userId = (req as any).user.id;
    const { startDate, endDate } = req.query;
    
    // Verify employee belongs to authenticated user
    const employee = await db.select()
      .from(employees)
      .where(eq(employees.id, employeeId))
      .limit(1);
      
    if (!employee || employee.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Employee not found'
      });
    }
    
    if (employee[0].userId !== userId && (req as any).user.role !== 'admin' && (req as any).user.role !== 'hr') {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized to view attendance for this employee'
      });
    }
    
    // Set default date range if not provided (last 30 days)
    const end = endDate ? new Date(endDate as string) : new Date();
    const start = startDate ? new Date(startDate as string) : new Date();
    start.setDate(start.getDate() - 30);
    
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return res.status(400).json({
        success: false,
        message: 'Invalid date format for startDate or endDate'
      });
    }
    
    // Get attendance records
    const attendanceRecords = await db.select()
      .from(attendance)
      .where(
        and(
          eq(attendance.employeeId, employeeId),
          gte(attendance.date, start.toISOString()),
          lte(attendance.date, end.toISOString())
        )
      )
      .orderBy(desc(attendance.date));
    
    // Format for mobile consumption
    const formattedRecords = attendanceRecords.map(record => ({
      id: record.id,
      date: record.date,
      checkIn: record.checkIn,
      checkOut: record.checkOut,
      status: record.status,
      hoursWorked: record.hoursWorked || 0,
      isComplete: !!record.checkIn && !!record.checkOut
    }));
    
    res.status(200).json({
      success: true,
      employeeId,
      period: {
        from: start.toISOString().split('T')[0],
        to: end.toISOString().split('T')[0]
      },
      attendanceRecords: formattedRecords,
      count: formattedRecords.length
    });
  } catch (error) {
    console.error('Attendance history error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error retrieving attendance history',
      error: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

export default router;