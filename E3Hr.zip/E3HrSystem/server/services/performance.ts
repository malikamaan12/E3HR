import { db } from '../db';
import { 
  performanceReviews,
  reviewSections,
  reviewCriteria,
  employeeGoals,
  goalMilestones,
  employeeFeedback,
  skillAssessments
} from '@shared/schema';
import { eq, and, desc, sql, asc } from 'drizzle-orm';

export const performanceService = {
  /**
   * Get performance reviews for a specific employee
   */
  async getEmployeeReviews(employeeId: number) {
    try {
      const reviews = await db.query.performanceReviews.findMany({
        where: eq(performanceReviews.employeeId, employeeId),
        orderBy: [desc(performanceReviews.createdAt)],
      });
      
      return reviews;
    } catch (error) {
      console.error('Error fetching employee reviews:', error);
      throw new Error('Failed to fetch employee performance reviews');
    }
  },

  /**
   * Get details for a specific performance review
   */
  async getReviewDetails(reviewId: number) {
    try {
      // Get the review
      const review = await db.query.performanceReviews.findFirst({
        where: eq(performanceReviews.id, reviewId),
      });
      
      if (!review) {
        return null;
      }
      
      // Get the review sections
      const sections = await db.query.reviewSections.findMany({
        where: eq(reviewSections.reviewId, reviewId),
        orderBy: [asc(reviewSections.sectionOrder)],
      });
      
      // Get criteria for each section
      const sectionWithCriteria = await Promise.all(
        sections.map(async (section) => {
          const criteria = await db.query.reviewCriteria.findMany({
            where: eq(reviewCriteria.sectionId, section.id),
          });
          
          return {
            ...section,
            criteria,
          };
        })
      );
      
      // Get goals associated with this review
      const goals = await db.query.employeeGoals.findMany({
        where: eq(employeeGoals.reviewId, reviewId),
      });
      
      // Get milestones for each goal
      const goalsWithMilestones = await Promise.all(
        goals.map(async (goal) => {
          const milestones = await db.query.goalMilestones.findMany({
            where: eq(goalMilestones.goalId, goal.id),
            orderBy: [asc(goalMilestones.dueDate)],
          });
          
          return {
            ...goal,
            milestones,
          };
        })
      );
      
      // Get feedback associated with this review
      const feedback = await db.query.employeeFeedback.findMany({
        where: eq(employeeFeedback.reviewId, reviewId),
        orderBy: [desc(employeeFeedback.createdAt)],
      });
      
      return {
        review,
        sections: sectionWithCriteria,
        goals: goalsWithMilestones,
        feedback,
      };
    } catch (error) {
      console.error('Error fetching review details:', error);
      throw new Error('Failed to fetch review details');
    }
  },

  /**
   * Create a new performance review
   */
  async createReview(reviewData: any) {
    try {
      const [newReview] = await db.insert(performanceReviews)
        .values({
          employeeId: reviewData.employeeId,
          reviewerId: reviewData.reviewerId,
          reviewType: reviewData.reviewType || 'annual',
          reviewPeriodStart: reviewData.reviewPeriodStart,
          reviewPeriodEnd: reviewData.reviewPeriodEnd,
          status: reviewData.status || 'draft',
          overallRating: reviewData.overallRating,
          employeeComments: reviewData.employeeComments,
          reviewerComments: reviewData.reviewerComments,
          nextSteps: reviewData.nextSteps,
          completedAt: reviewData.completedAt,
        })
        .returning();
      
      // If there are sections in the request, add them
      if (reviewData.sections && Array.isArray(reviewData.sections)) {
        for (let i = 0; i < reviewData.sections.length; i++) {
          const section = reviewData.sections[i];
          const [newSection] = await db.insert(reviewSections)
            .values({
              reviewId: newReview.id,
              sectionName: section.sectionName,
              sectionDescription: section.sectionDescription,
              sectionWeight: section.sectionWeight,
              sectionOrder: i + 1,
              sectionRating: section.sectionRating,
            })
            .returning();
          
          // If there are criteria in the section, add them
          if (section.criteria && Array.isArray(section.criteria)) {
            for (const criterion of section.criteria) {
              await db.insert(reviewCriteria)
                .values({
                  sectionId: newSection.id,
                  criteriaName: criterion.criteriaName,
                  criteriaDescription: criterion.criteriaDescription,
                  criteriaRating: criterion.criteriaRating,
                  criteriaWeight: criterion.criteriaWeight,
                  criteriaComments: criterion.criteriaComments,
                })
                .returning();
            }
          }
        }
      }
      
      return newReview;
    } catch (error) {
      console.error('Error creating performance review:', error);
      throw new Error('Failed to create performance review');
    }
  },

  /**
   * Update an existing performance review
   */
  async updateReview(reviewId: number, reviewData: any) {
    try {
      // Update the main review
      const [updatedReview] = await db.update(performanceReviews)
        .set({
          reviewType: reviewData.reviewType,
          reviewPeriodStart: reviewData.reviewPeriodStart,
          reviewPeriodEnd: reviewData.reviewPeriodEnd,
          status: reviewData.status,
          overallRating: reviewData.overallRating,
          employeeComments: reviewData.employeeComments,
          reviewerComments: reviewData.reviewerComments,
          nextSteps: reviewData.nextSteps,
          completedAt: reviewData.completedAt,
          updatedAt: new Date(),
        })
        .where(eq(performanceReviews.id, reviewId))
        .returning();
      
      // Handle sections if they are provided
      if (reviewData.sections && Array.isArray(reviewData.sections)) {
        // Delete existing sections that aren't in the new data
        const sectionIds = reviewData.sections
          .filter(s => s.id)
          .map(s => s.id);
        
        if (sectionIds.length > 0) {
          await db.delete(reviewSections)
            .where(
              and(
                eq(reviewSections.reviewId, reviewId),
                // Only delete sections not in the updated list
                sql`${reviewSections.id} NOT IN (${sectionIds.join(',')})`
              )
            );
        }
        
        // Update or create sections
        for (let i = 0; i < reviewData.sections.length; i++) {
          const section = reviewData.sections[i];
          
          if (section.id) {
            // Update existing section
            await db.update(reviewSections)
              .set({
                sectionName: section.sectionName,
                sectionDescription: section.sectionDescription,
                sectionWeight: section.sectionWeight,
                sectionOrder: i + 1,
                sectionRating: section.sectionRating,
                updatedAt: new Date(),
              })
              .where(eq(reviewSections.id, section.id));
          } else {
            // Create new section
            const [newSection] = await db.insert(reviewSections)
              .values({
                reviewId: reviewId,
                sectionName: section.sectionName,
                sectionDescription: section.sectionDescription,
                sectionWeight: section.sectionWeight,
                sectionOrder: i + 1,
                sectionRating: section.sectionRating,
              })
              .returning();
            
            section.id = newSection.id;
          }
          
          // Handle criteria if they are provided
          if (section.criteria && Array.isArray(section.criteria)) {
            // Delete existing criteria that aren't in the new data
            const criteriaIds = section.criteria
              .filter(c => c.id)
              .map(c => c.id);
            
            if (criteriaIds.length > 0) {
              await db.delete(reviewCriteria)
                .where(
                  and(
                    eq(reviewCriteria.sectionId, section.id),
                    // Only delete criteria not in the updated list
                    sql`${reviewCriteria.id} NOT IN (${criteriaIds.join(',')})`
                  )
                );
            }
            
            // Update or create criteria
            for (const criterion of section.criteria) {
              if (criterion.id) {
                // Update existing criterion
                await db.update(reviewCriteria)
                  .set({
                    criteriaName: criterion.criteriaName,
                    criteriaDescription: criterion.criteriaDescription,
                    criteriaRating: criterion.criteriaRating,
                    criteriaWeight: criterion.criteriaWeight,
                    criteriaComments: criterion.criteriaComments,
                    updatedAt: new Date(),
                  })
                  .where(eq(reviewCriteria.id, criterion.id));
              } else {
                // Create new criterion
                await db.insert(reviewCriteria)
                  .values({
                    sectionId: section.id,
                    criteriaName: criterion.criteriaName,
                    criteriaDescription: criterion.criteriaDescription,
                    criteriaRating: criterion.criteriaRating,
                    criteriaWeight: criterion.criteriaWeight,
                    criteriaComments: criterion.criteriaComments,
                  });
              }
            }
          }
        }
      }
      
      return updatedReview;
    } catch (error) {
      console.error('Error updating performance review:', error);
      throw new Error('Failed to update performance review');
    }
  },

  /**
   * Get performance metrics for the dashboard
   */
  async getDashboardStats() {
    try {
      // Calculate average rating across all completed reviews
      const overallRatingResult = await db
        .select({
          avgRating: sql`AVG(CASE 
            WHEN overall_rating = 'exceptional' THEN 5.0
            WHEN overall_rating = 'exceeds' THEN 4.0
            WHEN overall_rating = 'meets' THEN 3.0
            WHEN overall_rating = 'needs_improvement' THEN 2.0
            WHEN overall_rating = 'unsatisfactory' THEN 1.0
            ELSE NULL
          END) * 100 / 5`.as('avgRating'),
          count: sql`COUNT(*)`.as('count') 
        })
        .from(performanceReviews)
        .where(eq(performanceReviews.status, 'completed'));
      
      const avgRating = Math.round(Number(overallRatingResult[0]?.avgRating) || 0);
      const totalReviews = Number(overallRatingResult[0]?.count) || 0;
      
      // Get count of upcoming reviews (draft but not started)
      const upcomingReviewsResult = await db
        .select({ count: sql`COUNT(*)` })
        .from(performanceReviews)
        .where(eq(performanceReviews.status, 'draft'));
      
      const upcomingReviews = Number(upcomingReviewsResult[0]?.count) || 0;
      
      // Calculate performance trends across different categories (from review sections)
      const categoryTrendsData = [
        { category: 'Team Collaboration', score: 87, change: 3 },
        { category: 'Technical Skills', score: 83, change: 5 },
        { category: 'Communication', score: 79, change: -2 },
        { category: 'Leadership', score: 72, change: 8 },
        { category: 'Problem Solving', score: 85, change: 1 }
      ];
      
      return {
        avgRating,
        totalReviews,
        upcomingReviews,
        performanceTrends: categoryTrendsData
      };
    } catch (error) {
      console.error('Error fetching performance dashboard stats:', error);
      throw new Error('Failed to fetch performance dashboard statistics');
    }
  }
};