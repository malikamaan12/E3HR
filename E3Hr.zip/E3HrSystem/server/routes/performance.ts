import { Express, Request, Response } from 'express';
import { db } from '../db';
import { performanceService } from '../services/performance';

export function registerPerformanceRoutes(app: Express) {
  // Get dashboard stats for performance management
  app.get('/api/performance/dashboard-stats', async (_req: Request, res: Response) => {
    try {
      const stats = await performanceService.getDashboardStats();
      return res.status(200).json(stats);
    } catch (error) {
      console.error('[API] Error fetching performance dashboard stats:', error);
      return res.status(500).json({ error: 'Failed to fetch performance dashboard statistics' });
    }
  });

  // Get performance reviews for an employee
  app.get('/api/performance/employee/:id/reviews', async (req: Request, res: Response) => {
    try {
      const employeeId = parseInt(req.params.id);
      if (isNaN(employeeId)) {
        return res.status(400).json({ error: 'Invalid employee ID' });
      }

      const reviews = await performanceService.getEmployeeReviews(employeeId);
      return res.status(200).json(reviews);
    } catch (error) {
      console.error('[API] Error fetching employee reviews:', error);
      return res.status(500).json({ error: 'Failed to fetch employee performance reviews' });
    }
  });

  // Create a new performance review
  app.post('/api/performance/reviews', async (req: Request, res: Response) => {
    try {
      const reviewData = req.body;
      const newReview = await performanceService.createReview(reviewData);
      return res.status(201).json(newReview);
    } catch (error) {
      console.error('[API] Error creating performance review:', error);
      return res.status(500).json({ error: 'Failed to create performance review' });
    }
  });

  // Get details for a specific performance review
  app.get('/api/performance/reviews/:id', async (req: Request, res: Response) => {
    try {
      const reviewId = parseInt(req.params.id);
      if (isNaN(reviewId)) {
        return res.status(400).json({ error: 'Invalid review ID' });
      }

      const review = await performanceService.getReviewDetails(reviewId);
      if (!review) {
        return res.status(404).json({ error: 'Review not found' });
      }

      return res.status(200).json(review);
    } catch (error) {
      console.error('[API] Error fetching review details:', error);
      return res.status(500).json({ error: 'Failed to fetch review details' });
    }
  });

  // Update a performance review
  app.patch('/api/performance/reviews/:id', async (req: Request, res: Response) => {
    try {
      const reviewId = parseInt(req.params.id);
      if (isNaN(reviewId)) {
        return res.status(400).json({ error: 'Invalid review ID' });
      }

      const reviewData = req.body;
      const updatedReview = await performanceService.updateReview(reviewId, reviewData);
      return res.status(200).json(updatedReview);
    } catch (error) {
      console.error('[API] Error updating review:', error);
      return res.status(500).json({ error: 'Failed to update review' });
    }
  });
}