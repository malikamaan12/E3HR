import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Calendar, 
  Clock, 
  FileText, 
  DollarSign, 
  Users, 
  Award,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  XCircle,
  Timer,
  CalendarDays,
  Briefcase,
  User,
  Shield,
  Settings,
  BarChart3
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { usePermissions, PermissionGuard } from '@/hooks/usePermissions';
import { Link } from 'wouter';

interface DashboardData {
  attendance: {
    status: string;
    checkInTime: string | null;
    totalHours: number;
    monthlyAttendance: number;
  };
  leaves: {
    available: number;
    used: number;
    pending: number;
    upcoming: any[];
  };
  documents: {
    total: number;
    expiring: number;
  };
  performance: {
    rating: number;
    lastReview: string;
    goals: number;
  };
  payroll: {
    lastPayslip: string;
    nextPayDate: string;
  };
}

const EmployeeDashboard: React.FC = () => {
  const { user } = useAuth();
  const permissions = usePermissions();
  
  // Fetch dashboard data
  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: ['/api/employee/dashboard'],
    enabled: !!user,
  });

  // Determine feature access based on employee type
  const getFeatureAccess = () => {
    switch (user?.employeeType) {
      case 'temporary':
        return {
          attendance: true,
          leaves: true,
          documents: true,
          performance: false,
          payroll: false,
          events: false,
          training: false,
        };
      case 'contract':
        return {
          attendance: true,
          leaves: true,
          documents: true,
          performance: true,
          payroll: true,
          events: false,
          training: false,
        };
      case 'permanent':
      default:
        return {
          attendance: true,
          leaves: true,
          documents: true,
          performance: true,
          payroll: true,
          events: true,
          training: true,
        };
    }
  };

  const features = getFeatureAccess();

  const getEmployeeTypeBadge = () => {
    const type = user?.employeeType || 'permanent';
    const colors = {
      permanent: 'bg-green-100 text-green-800',
      temporary: 'bg-yellow-100 text-yellow-800',
      contract: 'bg-blue-100 text-blue-800',
    };
    
    return (
      <Badge className={colors[type]}>
        {type.charAt(0).toUpperCase() + type.slice(1)} Employee
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-primary to-primary-dark text-white p-6 rounded-lg">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              Welcome back, {user?.firstName}!
            </h1>
            <p className="text-white/90">
              Here's your dashboard overview for today
            </p>
          </div>
          <div className="text-right">
            {getEmployeeTypeBadge()}
            <div className="mt-2 text-sm text-white/80">
              Role: {permissions.userRole}
            </div>
            <p className="text-sm text-white/80 mt-2">
              Department: {user?.department || 'Not assigned'}
            </p>
          </div>
        </div>
      </div>

      {/* Quick Actions - Using Permission System */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <PermissionGuard module="attendance_time_tracking" permission="read">
          <Link href="/attendance">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardContent className="flex flex-col items-center justify-center p-6">
                <Clock className="h-8 w-8 text-primary mb-2" />
                <span className="text-sm font-medium">Clock In/Out</span>
                {dashboardData?.attendance.status && (
                  <Badge variant="outline" className="mt-2">
                    {dashboardData.attendance.status}
                  </Badge>
                )}
              </CardContent>
            </Card>
          </Link>
        </PermissionGuard>
        
        <PermissionGuard module="leave_absence_management" permission="read">
          <Link href="/leave">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardContent className="flex flex-col items-center justify-center p-6">
                <CalendarDays className="h-8 w-8 text-primary mb-2" />
                <span className="text-sm font-medium">Request Leave</span>
                <span className="text-xs text-muted-foreground mt-1">
                  {dashboardData?.leaves.available || 0} days available
                </span>
              </CardContent>
            </Card>
          </Link>
        </PermissionGuard>
        
        <PermissionGuard module="compliance_documents" permission="read">
          <Link href="/documents">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardContent className="flex flex-col items-center justify-center p-6">
                <FileText className="h-8 w-8 text-primary mb-2" />
                <span className="text-sm font-medium">My Documents</span>
                {dashboardData?.documents.expiring > 0 && (
                  <Badge variant="destructive" className="mt-2">
                    {dashboardData.documents.expiring} expiring
                  </Badge>
                )}
              </CardContent>
            </Card>
          </Link>
        </PermissionGuard>
        
        <PermissionGuard module="payroll_management" permission="read">
          <Link href="/payroll">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardContent className="flex flex-col items-center justify-center p-6">
                <DollarSign className="h-8 w-8 text-primary mb-2" />
                <span className="text-sm font-medium">Payslips</span>
                <span className="text-xs text-muted-foreground mt-1">
                  Next: {dashboardData?.payroll.nextPayDate || 'N/A'}
                </span>
              </CardContent>
            </Card>
          </Link>
        </PermissionGuard>
      </div>

      {/* Role-Specific Administrative Sections */}
      
      {/* Super Admin / Admin Dashboard */}
      <PermissionGuard module="system_configuration" permission="admin">
        <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-800">
              <Shield className="h-5 w-5" />
              System Administration
            </CardTitle>
            <CardDescription>System-wide controls and monitoring</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Link href="/user-management">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Users className="h-6 w-6 text-red-600 mb-2" />
                    <span className="text-sm font-medium">User Management</span>
                  </CardContent>
                </Card>
              </Link>
              <Link href="/settings">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Settings className="h-6 w-6 text-red-600 mb-2" />
                    <span className="text-sm font-medium">System Settings</span>
                  </CardContent>
                </Card>
              </Link>
              <Link href="/reports">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <BarChart3 className="h-6 w-6 text-red-600 mb-2" />
                    <span className="text-sm font-medium">Analytics</span>
                  </CardContent>
                </Card>
              </Link>
              <Card className="bg-white">
                <CardContent className="flex flex-col items-center justify-center p-4">
                  <CheckCircle className="h-6 w-6 text-green-600 mb-2" />
                  <span className="text-xs text-center">System Status: Healthy</span>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </PermissionGuard>

      {/* HR Management Dashboard */}
      <PermissionGuard module="employee_database" permission="admin">
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800">
              <Users className="h-5 w-5" />
              HR Management Console
            </CardTitle>
            <CardDescription>Employee lifecycle and HR operations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Link href="/recruitment">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <User className="h-6 w-6 text-blue-600 mb-2" />
                    <span className="text-sm font-medium">Recruitment</span>
                  </CardContent>
                </Card>
              </Link>
              <Link href="/employees">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Users className="h-6 w-6 text-blue-600 mb-2" />
                    <span className="text-sm font-medium">Employee DB</span>
                  </CardContent>
                </Card>
              </Link>
              <Link href="/performance">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Award className="h-6 w-6 text-blue-600 mb-2" />
                    <span className="text-sm font-medium">Performance</span>
                  </CardContent>
                </Card>
              </Link>
              <Link href="/onboarding">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Briefcase className="h-6 w-6 text-blue-600 mb-2" />
                    <span className="text-sm font-medium">Onboarding</span>
                  </CardContent>
                </Card>
              </Link>
            </div>
          </CardContent>
        </Card>
      </PermissionGuard>

      {/* Finance/Payroll Dashboard */}
      <PermissionGuard module="payroll_management" permission="admin">
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <DollarSign className="h-5 w-5" />
              Financial Management
            </CardTitle>
            <CardDescription>Payroll, benefits, and financial controls</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <Link href="/payroll">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <DollarSign className="h-6 w-6 text-green-600 mb-2" />
                    <span className="text-sm font-medium">Payroll</span>
                  </CardContent>
                </Card>
              </Link>
              <Link href="/benefits">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Award className="h-6 w-6 text-green-600 mb-2" />
                    <span className="text-sm font-medium">Benefits</span>
                  </CardContent>
                </Card>
              </Link>
              <Card className="bg-white">
                <CardContent className="flex flex-col items-center justify-center p-4">
                  <TrendingUp className="h-6 w-6 text-green-600 mb-2" />
                  <span className="text-xs text-center">Budget Status: On Track</span>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </PermissionGuard>

      {/* Event Management Dashboard */}
      <PermissionGuard module="event_staff_management" permission="admin">
        <Card className="bg-gradient-to-r from-purple-50 to-violet-50 border-purple-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-purple-800">
              <Calendar className="h-5 w-5" />
              Event Staff Management
            </CardTitle>
            <CardDescription>Event coordination and staff assignment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <Link href="/event-staff">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Users className="h-6 w-6 text-purple-600 mb-2" />
                    <span className="text-sm font-medium">Staff Assignment</span>
                  </CardContent>
                </Card>
              </Link>
              <Link href="/events">
                <Card className="cursor-pointer hover:shadow-md transition-shadow bg-white">
                  <CardContent className="flex flex-col items-center justify-center p-4">
                    <Calendar className="h-6 w-6 text-purple-600 mb-2" />
                    <span className="text-sm font-medium">Events</span>
                  </CardContent>
                </Card>
              </Link>
              <Card className="bg-white">
                <CardContent className="flex flex-col items-center justify-center p-4">
                  <CheckCircle className="h-6 w-6 text-purple-600 mb-2" />
                  <span className="text-xs text-center">3 Active Events</span>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </PermissionGuard>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="activities">Recent Activities</TabsTrigger>
          <TabsTrigger value="tasks">My Tasks</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Attendance Card */}
            {features.attendance && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Attendance This Month
                  </CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {dashboardData?.attendance.monthlyAttendance || 0}%
                  </div>
                  <Progress 
                    value={dashboardData?.attendance.monthlyAttendance || 0} 
                    className="mt-2"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    {dashboardData?.attendance.checkInTime 
                      ? `Checked in at ${dashboardData.attendance.checkInTime}`
                      : 'Not checked in today'}
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Leave Balance Card */}
            {features.leaves && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Leave Balance
                  </CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {dashboardData?.leaves.available || 0} days
                  </div>
                  <div className="mt-2 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span>Used</span>
                      <span>{dashboardData?.leaves.used || 0} days</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span>Pending</span>
                      <span>{dashboardData?.leaves.pending || 0} requests</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Performance Card - Only for eligible employees */}
            {features.performance && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">
                    Performance Rating
                  </CardTitle>
                  <Award className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {dashboardData?.performance.rating || 'N/A'}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Last review: {dashboardData?.performance.lastReview || 'No reviews yet'}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Active goals: {dashboardData?.performance.goals || 0}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Feature Restrictions Notice for Temporary Employees */}
          {user?.employeeType === 'temporary' && (
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <AlertCircle className="h-4 w-4 mr-2 text-yellow-600" />
                  Limited Access Account
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  As a temporary employee, you have access to:
                </p>
                <ul className="mt-2 space-y-1 text-sm">
                  <li className="flex items-center">
                    <CheckCircle className="h-3 w-3 mr-2 text-green-600" />
                    Attendance tracking
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-3 w-3 mr-2 text-green-600" />
                    Leave requests
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-3 w-3 mr-2 text-green-600" />
                    Document viewing
                  </li>
                  <li className="flex items-center">
                    <XCircle className="h-3 w-3 mr-2 text-red-600" />
                    Performance reviews (Not available)
                  </li>
                  <li className="flex items-center">
                    <XCircle className="h-3 w-3 mr-2 text-red-600" />
                    Payroll access (Not available)
                  </li>
                </ul>
              </CardContent>
            </Card>
          )}

          {/* Contract End Date Warning */}
          {(user?.employeeType === 'temporary' || user?.employeeType === 'contract') && user?.contractEndDate && (
            <Card className="border-orange-200 bg-orange-50">
              <CardHeader>
                <CardTitle className="text-sm flex items-center">
                  <Timer className="h-4 w-4 mr-2 text-orange-600" />
                  Contract Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm">
                  Your contract ends on: <strong>{new Date(user.contractEndDate).toLocaleDateString()}</strong>
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Please contact HR for renewal or extension inquiries.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="activities" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activities</CardTitle>
              <CardDescription>Your latest actions and updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Activity items would be loaded here */}
                <div className="text-sm text-muted-foreground text-center py-4">
                  No recent activities to display
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tasks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>My Tasks</CardTitle>
              <CardDescription>Tasks and actions assigned to you</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Task items would be loaded here */}
                <div className="text-sm text-muted-foreground text-center py-4">
                  No pending tasks
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EmployeeDashboard;