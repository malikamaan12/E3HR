import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import WelcomeBanner from "@/components/dashboard/WelcomeBanner";
import QuickActions from "@/components/dashboard/QuickActions";
import RecentActivity from "@/components/dashboard/RecentActivity";
import AttendanceOverview from "@/components/dashboard/AttendanceOverview";
import ComplianceStatus from "@/components/dashboard/ComplianceStatus";
import UpcomingEvents from "@/components/dashboard/UpcomingEvents";
import PerformanceOverview from "@/components/dashboard/PerformanceOverview";
import TrainingOverview from "@/components/dashboard/TrainingOverview";
import AnalyticsOverview from "@/components/dashboard/AnalyticsOverview";
import RolePermissionOverview from "@/components/dashboard/RolePermissionOverview";
import SkillGapOverview from "@/components/dashboard/SkillGapOverview";
import MobileIntegrationOverview from "@/components/dashboard/MobileIntegrationOverview";
import EmployeeDashboard from "./EmployeeDashboard";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    staleTime: 1000 * 60,
  });

  const fallbackStats = {
    employeeCount: 248,
    activeLeaves: 15,
    expiringDocuments: 12,
    upcomingEvents: 4
  };

  const dashboardStats = stats || fallbackStats;

  if (user?.role === 'employee' || user?.role === 'event_staff') {
    return <EmployeeDashboard />;
  }

  return (
    <div className="space-y-6 pb-12 max-w-full overflow-hidden">
      <WelcomeBanner stats={dashboardStats as any} />

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        <div className="md:col-span-2">
          <QuickActions />
        </div>
        <div className="md:col-span-1">
          <ComplianceStatus />
        </div>
        <div className="md:col-span-1">
          <UpcomingEvents />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AttendanceOverview />
        <RecentActivity />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SkillGapOverview />
        <TrainingOverview />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PerformanceOverview />
        <AnalyticsOverview />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <RolePermissionOverview />
        <MobileIntegrationOverview />
      </div>
    </div>
  );
}
