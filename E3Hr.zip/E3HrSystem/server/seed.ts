import { db } from "./db";
import { users } from "@shared/schema";
import bcrypt from "bcryptjs";
import { seedOnboardingData } from "./seed/onboardingData";

async function seedDatabase() {
  try {
    console.log("🌱 Checking database users...");

    // Check if users already exist
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      console.log("✅ Users already exist, skipping seed");
      return;
    }

    // Hash passwords for default users
    const defaultPassword = "password123";
    const hashedPassword = await bcrypt.hash(defaultPassword, 12);

    // Create default users (only with columns that exist in database)
    const defaultUsers = [
      {
        username: "admin",
        password: hashedPassword,
        email: "admin@e3hr.com",
        firstName: "System",
        lastName: "Administrator",
        role: "admin" as const,
        department: "IT",
      },
      {
        username: "hrmanager",
        password: hashedPassword,
        email: "hr@e3hr.com",
        firstName: "Ahmad",
        lastName: "Al-Mansoori",
        role: "hr" as const,
        department: "Human Resources",
      },
      {
        username: "employee",
        password: hashedPassword,
        email: "employee@e3hr.com",
        firstName: "Mohammed",
        lastName: "Al-Thani",
        role: "employee" as const,
        department: "Operations",
      },
      {
        username: "finance",
        password: hashedPassword,
        email: "finance@e3hr.com",
        firstName: "Sara",
        lastName: "Al-Sulaiti",
        role: "finance" as const,
        department: "Finance",
      },
      {
        username: "manager",
        password: hashedPassword,
        email: "manager@e3hr.com",
        firstName: "Fatima",
        lastName: "Al-Kuwari",
        role: "manager" as const,
        department: "Operations",
      }
    ];

    // Insert default users
    const createdUsers = await db.insert(users).values(defaultUsers).returning();

    console.log("✅ Successfully created default users:");
    console.log("📋 Default login credentials:");
    console.log("   Username: admin     | Password: password123 | Role: Administrator");
    console.log("   Username: hrmanager | Password: password123 | Role: HR Manager");
    console.log("   Username: employee  | Password: password123 | Role: Employee");
    console.log("   Username: finance   | Password: password123 | Role: Finance");
    console.log("   Username: manager   | Password: password123 | Role: Manager");
    console.log("");
    console.log("🔐 You can use any of these accounts to login to the system.");

    // Seed onboarding data
    await seedOnboardingData();

    return createdUsers;
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Run seed if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seedDatabase()
    .then(() => {
      console.log("🎉 Database seeding completed!");
      process.exit(0);
    })
    .catch((error) => {
      console.error("💥 Database seeding failed:", error);
      process.exit(1);
    });
}

export { seedDatabase };