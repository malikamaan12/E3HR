import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

export default function Reports() {
  const [reportPeriod, setReportPeriod] = useState("current_month");
  const [reportFormat, setReportFormat] = useState("pdf");
  
  const handleGenerateReport = (reportType: string) => {
    console.log(`Generating ${reportType} report for period: ${reportPeriod} in format: ${reportFormat}`);
    // In a real app, would make an API call to generate the report
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-poppins font-semibold">Reports & Analytics</CardTitle>
          <CardDescription>Generate and view comprehensive reports for your organization</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="reports">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="analytics">Analytics Dashboard</TabsTrigger>
            </TabsList>
            
            <TabsContent value="reports" className="space-y-6">
              <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 mb-6">
                <div className="sm:w-1/3">
                  <label className="text-sm text-neutral-500 mb-1 block">Report Period</label>
                  <Select value={reportPeriod} onValueChange={setReportPeriod}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="current_month">Current Month</SelectItem>
                      <SelectItem value="previous_month">Previous Month</SelectItem>
                      <SelectItem value="current_quarter">Current Quarter</SelectItem>
                      <SelectItem value="year_to_date">Year to Date</SelectItem>
                      <SelectItem value="custom">Custom Range</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="sm:w-1/3">
                  <label className="text-sm text-neutral-500 mb-1 block">Report Format</label>
                  <Select value={reportFormat} onValueChange={setReportFormat}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">HR Reports</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Employee Master List</h4>
                          <p className="text-sm text-neutral-500">Complete employee directory with details</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('employee_master')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Employee Turnover</h4>
                          <p className="text-sm text-neutral-500">Analysis of employee exits and retention</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('employee_turnover')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Department Headcount</h4>
                          <p className="text-sm text-neutral-500">Employee count by department</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('department_headcount')}
                        >
                          Generate
                        </Button>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Attendance Reports</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Attendance Summary</h4>
                          <p className="text-sm text-neutral-500">Summary of attendance by employee</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('attendance_summary')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Late Arrivals</h4>
                          <p className="text-sm text-neutral-500">Report of late check-ins</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('late_arrivals')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Overtime Analysis</h4>
                          <p className="text-sm text-neutral-500">Analysis of overtime hours worked</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('overtime_analysis')}
                        >
                          Generate
                        </Button>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Payroll Reports</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Payroll Summary</h4>
                          <p className="text-sm text-neutral-500">Summary of payroll for all employees</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('payroll_summary')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">WPS Compliance</h4>
                          <p className="text-sm text-neutral-500">Report for Wage Protection System</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('wps_compliance')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Allowances & Deductions</h4>
                          <p className="text-sm text-neutral-500">Breakdown of additional payments & deductions</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('allowances_deductions')}
                        >
                          Generate
                        </Button>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Compliance Reports</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Document Expiry</h4>
                          <p className="text-sm text-neutral-500">List of expiring employee documents</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('document_expiry')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Visa Status</h4>
                          <p className="text-sm text-neutral-500">Status report of employee visas</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('visa_status')}
                        >
                          Generate
                        </Button>
                      </li>
                      <li className="p-3 hover:bg-neutral-50 rounded-md flex justify-between items-center">
                        <div>
                          <h4 className="font-medium">Labor Law Compliance</h4>
                          <p className="text-sm text-neutral-500">Compliance with Qatar Labor Laws</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleGenerateReport('labor_law_compliance')}
                        >
                          Generate
                        </Button>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-neutral-500">Total Employees</p>
                        <p className="text-2xl font-semibold">248</p>
                      </div>
                      <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                        <i className="fas fa-users"></i>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-success">
                      <i className="fas fa-arrow-up mr-1"></i> 5% from last month
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-neutral-500">Avg. Attendance Rate</p>
                        <p className="text-2xl font-semibold">95.3%</p>
                      </div>
                      <div className="h-10 w-10 bg-success/10 rounded-full flex items-center justify-center text-success">
                        <i className="fas fa-check-circle"></i>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-success">
                      <i className="fas fa-arrow-up mr-1"></i> 1.2% from last month
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm text-neutral-500">Turnover Rate</p>
                        <p className="text-2xl font-semibold">3.2%</p>
                      </div>
                      <div className="h-10 w-10 bg-error/10 rounded-full flex items-center justify-center text-error">
                        <i className="fas fa-user-minus"></i>
                      </div>
                    </div>
                    <div className="mt-2 text-xs text-error">
                      <i className="fas fa-arrow-up mr-1"></i> 0.5% from last month
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Headcount by Department</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 w-full bg-neutral-50 rounded-lg flex items-center justify-center">
                      <div className="text-center">
                        <i className="fas fa-chart-pie text-4xl text-neutral-300 mb-2"></i>
                        <p className="text-neutral-500">Department Distribution Chart</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Attendance Trends</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 w-full bg-neutral-50 rounded-lg flex items-center justify-center">
                      <div className="text-center">
                        <i className="fas fa-chart-line text-4xl text-neutral-300 mb-2"></i>
                        <p className="text-neutral-500">Attendance Trend Chart</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Employee Type Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 w-full bg-neutral-50 rounded-lg flex items-center justify-center">
                      <div className="text-center">
                        <i className="fas fa-chart-bar text-4xl text-neutral-300 mb-2"></i>
                        <p className="text-neutral-500">Employee Type Chart</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Leave Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 w-full bg-neutral-50 rounded-lg flex items-center justify-center">
                      <div className="text-center">
                        <i className="fas fa-chart-pie text-4xl text-neutral-300 mb-2"></i>
                        <p className="text-neutral-500">Leave Type Distribution Chart</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
