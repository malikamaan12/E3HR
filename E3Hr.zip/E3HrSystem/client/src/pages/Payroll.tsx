import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { formatDate, getStatusClass } from "@/lib/utils";

export default function Payroll() {
  const [month, setMonth] = useState("10"); // October
  const [year, setYear] = useState("2023"); // Current year
  
  // Fetch payroll data - in a real app this would come from an API
  const { data: payrollData, isLoading, error } = useQuery({
    queryKey: [`/api/payroll/month/${month}/year/${year}`],
    staleTime: 1000 * 60, // 1 minute
  });

  // Fallback data if API is not available
  const fallbackPayroll = [
    {
      id: 1,
      employeeId: 1,
      employeeName: "Mohammed Al-Thani",
      month: 10,
      year: 2023,
      basicSalary: 12000,
      allowances: { housing: 3000, transport: 1000, other: 500 },
      deductions: { loans: 0, advances: 0, other: 0 },
      netSalary: 16500,
      status: "processed",
      wpsReference: "WPS-23A456",
      processedAt: "2023-10-25T08:30:00Z"
    },
    {
      id: 2,
      employeeId: 2,
      employeeName: "Sarah Johnson",
      month: 10,
      year: 2023,
      basicSalary: 9000,
      allowances: { housing: 2000, transport: 800, other: 200 },
      deductions: { loans: 500, advances: 0, other: 0 },
      netSalary: 11500,
      status: "processed",
      wpsReference: "WPS-23B789",
      processedAt: "2023-10-25T09:15:00Z"
    },
    {
      id: 3,
      employeeId: 3,
      employeeName: "Ahmed Hassan",
      month: 10,
      year: 2023,
      basicSalary: 10000,
      allowances: { housing: 2500, transport: 1000, other: 300 },
      deductions: { loans: 0, advances: 1000, other: 0 },
      netSalary: 12800,
      status: "pending",
      wpsReference: null,
      processedAt: null
    }
  ];

  const payroll = payrollData || fallbackPayroll;
  
  // Months for dropdown
  const months = [
    { value: "1", label: "January" },
    { value: "2", label: "February" },
    { value: "3", label: "March" },
    { value: "4", label: "April" },
    { value: "5", label: "May" },
    { value: "6", label: "June" },
    { value: "7", label: "July" },
    { value: "8", label: "August" },
    { value: "9", label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" }
  ];
  
  // Years for dropdown (current year and 2 previous years)
  const currentYear = new Date().getFullYear();
  const years = [
    { value: currentYear.toString(), label: currentYear.toString() },
    { value: (currentYear - 1).toString(), label: (currentYear - 1).toString() },
    { value: (currentYear - 2).toString(), label: (currentYear - 2).toString() }
  ];

  const calculateTotalAmount = () => {
    return payroll.reduce((total, item) => total + item.netSalary, 0).toLocaleString();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-xl font-poppins font-semibold">Payroll Management</CardTitle>
          <Button className="bg-primary hover:bg-primary/90">
            <i className="fas fa-plus mr-2"></i> Generate Payroll
          </Button>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4 mb-6">
            <div className="flex space-x-4">
              <div className="w-40">
                <label className="text-sm text-neutral-500 mb-1 block">Month</label>
                <Select value={month} onValueChange={setMonth}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select month" />
                  </SelectTrigger>
                  <SelectContent>
                    {months.map((m) => (
                      <SelectItem key={m.value} value={m.value}>
                        {m.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-32">
                <label className="text-sm text-neutral-500 mb-1 block">Year</label>
                <Select value={year} onValueChange={setYear}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year" />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map((y) => (
                      <SelectItem key={y.value} value={y.value}>
                        {y.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex-1"></div>
            <div className="flex items-end space-x-4">
              <Button variant="outline" className="space-x-2">
                <i className="fas fa-download"></i>
                <span>Export</span>
              </Button>
              <Button variant="outline" className="space-x-2">
                <i className="fas fa-file-csv"></i>
                <span>WPS File</span>
              </Button>
            </div>
          </div>

          <div className="mb-6 p-4 bg-primary/5 rounded-lg">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-neutral-500">Total Amount</p>
                <p className="text-2xl font-semibold text-primary">QAR {calculateTotalAmount()}</p>
              </div>
              <div>
                <Button className="bg-primary hover:bg-primary/90">
                  <i className="fas fa-paper-plane mr-2"></i> Submit to WPS
                </Button>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-neutral-200">
              <thead>
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Employee</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">Basic Salary</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">Allowances</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">Deductions</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">Net Salary</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">WPS Ref</th>
                  <th className="px-4 py-3 text-right text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-neutral-200">
                {isLoading ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-3 text-sm text-center text-neutral-500">Loading payroll data...</td>
                  </tr>
                ) : error ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-3 text-sm text-center text-error">Error loading payroll data</td>
                  </tr>
                ) : payroll.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-4 py-3 text-sm text-center text-neutral-500">No payroll data found for this period</td>
                  </tr>
                ) : (
                  payroll.map((item) => {
                    const totalAllowances = Object.values(item.allowances).reduce((sum: any, val: any) => sum + val, 0);
                    const totalDeductions = Object.values(item.deductions).reduce((sum: any, val: any) => sum + val, 0);
                    
                    return (
                      <tr key={item.id}>
                        <td className="px-4 py-3 text-sm font-medium text-neutral-800">
                          {item.employeeName}
                        </td>
                        <td className="px-4 py-3 text-sm text-neutral-800 text-right">
                          QAR {item.basicSalary.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-sm text-neutral-800 text-right">
                          QAR {totalAllowances.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-sm text-neutral-800 text-right">
                          QAR {totalDeductions.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-sm font-medium text-neutral-800 text-right">
                          QAR {item.netSalary.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 text-sm">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(item.status)}`}>
                            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-neutral-800">
                          {item.wpsReference || '-'}
                        </td>
                        <td className="px-4 py-3 text-sm text-right space-x-2">
                          <button className="text-primary hover:text-primary-dark">
                            <i className="fas fa-edit"></i>
                          </button>
                          <button className="text-neutral-500 hover:text-neutral-700">
                            <i className="fas fa-print"></i>
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
