import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  options: { 
    url: string;
    method: string;
    headers?: Record<string, string>;
    body?: string | FormData;
  } | string,
): Promise<Response> {
  // Handle both string and object formats for backward compatibility
  if (typeof options === 'string') {
    const res = await fetch(options, {
      credentials: "include",
    });
    await throwIfResNotOk(res);
    return res;
  }

  const { url, method, headers = {}, body } = options;
  
  // Don't set Content-Type for FormData as the browser will set it with the boundary
  const isFormData = body instanceof FormData;
  const finalHeaders: Record<string, string> = isFormData ? {} : { 'Content-Type': 'application/json', ...headers };
  
  // If body is already a string and the Content-Type is application/json,
  // assume it's already properly JSON stringified
  const isAlreadyStringified = typeof body === 'string' && 
    finalHeaders['Content-Type'] === 'application/json';
  
  const res = await fetch(url, {
    method,
    headers: finalHeaders,
    body: isFormData ? body : isAlreadyStringified ? body : JSON.stringify(body),
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
